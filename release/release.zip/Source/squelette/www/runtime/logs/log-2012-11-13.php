<?php exit; ?>

INFO - 2012-11-13 09:11:28 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:13:12 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:15:34 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:16:45 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:17:12 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:18:32 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:19:07 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:19:49 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:20:25 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-11-13 09:20:25 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-11-13 09:20:25 --> result.next={
	id : 1, 
	mdp : admin, 
	nom : admin
} ::> 
 Login.hx 125 success
INFO - 2012-11-13 09:20:27 --> index ::> 
 Pipo.hx 160 index
INFO - 2012-11-13 09:20:27 --> after ::> 
 Pipo.hx 166 index
INFO - 2012-11-13 09:21:44 --> index ::> 
 Pipo.hx 160 index
INFO - 2012-11-13 09:21:44 --> after ::> 
 Pipo.hx 166 index
INFO - 2012-11-13 09:25:01 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:25:50 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:28:22 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:29:16 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:30:08 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:43:47 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:44:11 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:45:17 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:46:05 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:48:30 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:49:08 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:51:02 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:51:16 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:51:30 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:51:32 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:51:44 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:52:27 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:52:52 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:53:38 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:54:11 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 09:54:45 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:00:51 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:00:59 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:01:23 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:02:02 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:03:12 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:03:54 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:04:47 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:05:10 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:07:31 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:08:01 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:08:25 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:08:32 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:08:45 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:16:16 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:18:51 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:19:07 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:22:16 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-11-13 10:24:36 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-11-13 10:24:36 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-11-13 10:24:36 --> result.next={
	id : 1, 
	mdp : admin, 
	nom : admin
} ::> 
 Login.hx 125 success
INFO - 2012-11-13 10:24:38 --> index ::> 
 Pipo.hx 160 index
INFO - 2012-11-13 10:24:38 --> after ::> 
 Pipo.hx 166 index
INFO - 2012-11-13 10:24:44 --> voName=News ::> 
 Pipo.hx 92 nav
INFO - 2012-11-13 10:24:44 --> choix id=null vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:24:44 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:24:45 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:24:45 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:24:45 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:24:45 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:24:45 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:24:45 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:24:45 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:24:45 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:24:45 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:24:45 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:24:45 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:24:45 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:24:45 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:24:45 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:24:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:24:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:24:45 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:29:42 --> voName=News ::> 
 Pipo.hx 92 nav
INFO - 2012-11-13 10:29:42 --> choix id=null vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:29:42 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:29:43 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:29:43 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:29:43 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:29:43 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:29:43 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:29:43 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:29:43 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:29:43 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:29:43 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:29:43 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:29:43 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:29:43 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:29:43 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:29:43 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:29:43 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:29:43 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:29:43 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:32:23 --> voName=News ::> 
 Pipo.hx 92 nav
INFO - 2012-11-13 10:32:23 --> choix id=null vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:32:23 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:32:24 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:32:24 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:32:24 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:32:24 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:32:24 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:32:24 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:32:24 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:32:24 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:32:24 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:32:24 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:32:24 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:32:24 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:32:24 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:32:24 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:32:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:32:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:32:24 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> choix id=9 vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:11 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:11 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:11 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:11 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:11 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:11 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:34:11 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:11 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:11 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:11 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:11 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:11 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:11 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:11 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:34:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:34:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:11 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:13 --> choix id=8 vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:13 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:34:13 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:13 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:13 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:34:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:34:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:13 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:16 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:16 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:16 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:16 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:16 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:16 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:34:16 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:16 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:16 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:16 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:16 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:16 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:16 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:16 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:34:16 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:34:16 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:16 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:18 --> choix id=5 vo=News ::> 
 Pipo.hx 107 choix
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:19 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:19 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:19 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:19 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:19 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:19 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:34:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:19 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:19 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:19 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:19 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:19 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:19 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:19 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:34:19 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:34:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:19 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:34:22 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:22 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:22 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:22 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:22 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:22 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:34:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:22 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:34:22 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:34:22 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:34:22 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:34:22 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:34:22 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:34:22 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:34:22 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:34:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:34:22 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:05 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:05 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:05 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:05 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:05 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:05 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:36:05 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:05 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:05 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:05 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:05 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:05 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:05 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:05 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:36:05 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:36:05 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:05 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:24 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:24 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:24 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:24 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:24 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:24 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:36:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:24 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:25 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:25 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:25 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:25 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:25 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:25 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:36:25 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:36:25 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:25 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:36:38 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:38 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:38 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:38 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:38 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:38 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:36:38 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:38 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:36:38 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:36:38 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:36:38 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:36:38 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:36:38 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:36:38 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:36:38 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:36:38 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:36:38 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:37:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:37:27 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:37:27 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:37:27 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:37:27 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:37:27 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:37:27 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:37:27 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:37:27 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:37:27 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:37:27 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:37:27 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:37:27 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:37:27 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:37:27 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:37:27 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:37:27 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:37:27 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:38:54 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:38:54 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:38:54 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:38:54 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:38:54 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:38:54 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:38:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:38:54 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:38:54 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:38:54 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:38:54 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:38:54 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:38:54 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:38:54 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:38:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:38:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:38:54 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:39:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:39:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:39:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:39:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:39:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:39:13 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:39:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:39:13 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:39:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:39:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:39:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:39:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:39:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:39:13 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:39:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:39:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:39:13 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:06 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:06 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:06 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:06 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:06 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:06 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:40:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:06 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:06 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:06 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:06 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:06 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:06 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:06 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:40:06 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:40:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:06 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:21 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:21 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:21 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:21 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:21 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:21 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:40:21 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:21 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:21 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:21 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:21 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:21 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:21 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:21 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:40:21 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:40:21 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:21 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:40:37 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:37 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:37 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:37 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:37 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:37 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:40:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:37 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:40:37 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:40:37 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:40:37 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:40:37 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:40:37 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:40:37 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:40:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:40:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:40:37 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:14 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:14 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:14 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:14 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:14 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:14 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:41:14 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:14 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:15 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:15 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:15 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:15 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:15 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:15 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:41:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:41:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:15 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:48 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:48 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:48 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:48 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:48 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:48 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:41:48 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:48 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:48 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:48 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:48 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:48 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:48 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:48 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:41:48 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:41:48 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:48 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:41:53 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:53 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:53 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:53 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:53 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:53 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:41:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:53 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:41:53 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:41:53 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:41:53 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:41:53 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:41:53 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:41:53 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:41:53 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:41:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:41:53 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:04 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:04 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:04 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:04 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:04 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:04 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:43:04 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:04 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:04 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:04 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:04 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:04 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:04 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:04 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:43:04 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:43:04 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:04 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:35 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:35 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:35 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:35 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:35 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:35 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:43:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:35 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:35 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:35 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:35 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:35 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:35 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:35 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:43:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:43:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:35 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:43:47 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:47 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:47 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:47 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:47 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:47 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:43:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:47 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:43:47 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:43:47 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:43:47 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:43:47 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:43:47 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:43:47 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:43:47 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:43:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:43:47 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:46:41 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:46:41 --> after ::> 
 Pipo.hx 167 index
INFO - 2012-11-13 10:46:46 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:46:46 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:46:46 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:46:47 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:46:47 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:46:47 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:46:47 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:46:47 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:46:47 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:46:47 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:46:47 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:46:47 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:46:48 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:46:48 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:46:48 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:46:48 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:46:48 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:46:48 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:46:48 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:46:48 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:30 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:48:30 --> after ::> 
 Pipo.hx 167 index
INFO - 2012-11-13 10:48:34 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:48:34 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:48:34 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:34 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:34 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:34 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:34 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:34 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:34 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:48:34 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:34 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:34 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:34 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:34 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:34 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:34 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:34 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:48:34 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:48:34 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:34 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:39 --> voName=Edito ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:48:39 --> choix id=null vo=Edito ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:48:39 --> Error occurred: Error while executing SELECT * FROM edito FOR UPDATE (Table 'microbe.edito' doesn't exist) ::> 
 Api.hx 217 getLast
INFO - 2012-11-13 10:48:40 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:48:40 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:48:40 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:41 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:41 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:41 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:41 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:41 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:41 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:48:41 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:41 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:41 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:41 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:41 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:41 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:41 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:41 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:48:41 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:48:41 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:41 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:42 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:48:42 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:48:42 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:48:43 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:43 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:43 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:43 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:43 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:43 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:48:43 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:43 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:43 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:48:43 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:48:43 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:48:43 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:48:43 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:48:43 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:48:43 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:48:43 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:48:43 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:48:45 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:48:45 --> after ::> 
 Pipo.hx 167 index
INFO - 2012-11-13 10:49:51 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:49:51 --> after ::> 
 Pipo.hx 167 index
INFO - 2012-11-13 10:51:23 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:51:23 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:51:25 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:51:25 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:51:25 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:51:26 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:51:26 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:51:26 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:51:26 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:51:26 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:51:26 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:51:26 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:51:26 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:51:26 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:51:26 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:51:26 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:51:26 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:51:26 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:51:26 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:51:26 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:51:26 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:51:26 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:51:28 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:51:28 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:52:04 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:52:04 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:52:06 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 10:52:06 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 10:52:06 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 10:52:06 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:52:06 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:52:06 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:52:06 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:52:06 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:52:06 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 10:52:06 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:52:06 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:52:06 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 10:52:06 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 10:52:06 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 10:52:06 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 10:52:06 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 10:52:06 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 10:52:06 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 10:52:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 10:52:06 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 10:52:19 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:52:19 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:54:58 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:54:59 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:55:22 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:55:22 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:56:15 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:56:15 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:56:42 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:56:42 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:58:36 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:58:36 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:58:53 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:58:53 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 10:59:28 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 10:59:28 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:03:49 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:03:49 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:10:03 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:10:03 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:10:22 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:10:22 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:10:56 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:10:56 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:11:03 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:11:03 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:11:03 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:11:04 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:11:04 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:11:04 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:11:04 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:11:04 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:11:04 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:11:04 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:11:04 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:11:04 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:11:04 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:11:04 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:11:04 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:11:04 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:11:04 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:11:04 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:11:04 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:11:04 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:11:11 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:11:11 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:12:11 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:12:11 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:12:14 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:12:14 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:12:14 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:15 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:12:15 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:12:15 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:12:15 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:12:15 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:12:15 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:12:15 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:12:15 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:12:15 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:12:15 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:12:15 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:12:15 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:12:15 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:12:15 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:12:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:12:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:12:15 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:12:19 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:12:19 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:12:19 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:12:20 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:12:20 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:12:20 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:12:20 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:12:20 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:12:20 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:12:20 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:12:20 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:12:20 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:12:20 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:12:20 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:12:20 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:12:20 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:12:20 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:12:20 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:12:20 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:12:20 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:16:25 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:16:25 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:16:25 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:16:26 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:16:26 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:16:26 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:16:26 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:16:26 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:16:26 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:16:26 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:16:26 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:16:26 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:16:26 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:16:26 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:16:26 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:16:26 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:16:26 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:16:26 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:16:26 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:16:26 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:20:21 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:20:21 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:20:21 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:20:22 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:20:22 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:20:22 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:20:22 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:20:22 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:20:22 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:20:22 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:20:22 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:20:22 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:20:22 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:20:22 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:20:22 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:20:22 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:20:22 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:20:22 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:20:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:20:22 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:20:27 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:20:27 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:21:47 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:21:47 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:21:49 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:21:49 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:21:49 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:21:50 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:21:50 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:21:50 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:21:50 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:21:50 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:21:50 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:21:50 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:21:50 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:21:50 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:21:50 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:21:50 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:21:50 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:21:50 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:21:50 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:21:50 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:21:50 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:21:50 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:22:27 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 11:22:27 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 11:22:30 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:22:30 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:22:30 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:30 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:22:30 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:22:30 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:22:30 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:22:30 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:22:30 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:22:30 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:22:30 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:22:31 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:22:31 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:22:31 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:22:31 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:22:31 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:22:31 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:22:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:22:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:22:31 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:22:37 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 11:22:37 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 11:22:37 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 11:22:37 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:22:37 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:22:37 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:22:37 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:22:37 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:22:37 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 11:22:37 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:22:37 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 11:22:37 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 11:22:37 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 11:22:37 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 11:22:37 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 11:22:37 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 11:22:37 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 11:22:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 11:22:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 11:22:37 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:31:02 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:31:02 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 13:50:09 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:52:51 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:53:04 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:53:04 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 13:53:06 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 13:53:06 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:06 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:06 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:06 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:06 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:06 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:06 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:06 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 13:53:06 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:06 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:07 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:07 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:07 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:07 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:07 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:07 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 13:53:07 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 13:53:07 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:07 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:10 --> voName=Edito ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 13:53:10 --> choix id=null vo=Edito ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:10 --> Error occurred: Error while executing SELECT * FROM edito FOR UPDATE (Table 'microbe.edito' doesn't exist) ::> 
 Api.hx 217 getLast
INFO - 2012-11-13 13:53:12 --> voName=News ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 13:53:12 --> choix id=null vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:12 --> micrabeLast ::> 
 Api.hx 223 getLast
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:13 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 13:53:13 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:13 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:13 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:13 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:13 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:13 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:13 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:13 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 13:53:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 13:53:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:13 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:18 --> ajoute ::> 
 Pipo.hx 271 ajoute
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> ajoute ::> 
 Pipo.hx 271 ajoute
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> ajoute ::> 
 Pipo.hx 271 ajoute
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:31 --> voName=Edito ::> 
 Pipo.hx 93 nav
INFO - 2012-11-13 13:53:31 --> choix id=null vo=Edito ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:31 --> Error occurred: Error while executing SELECT * FROM edito FOR UPDATE (Table 'microbe.edito' doesn't exist) ::> 
 Api.hx 217 getLast
INFO - 2012-11-13 13:53:32 --> ajoute ::> 
 Pipo.hx 271 ajoute
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> choix id=5 vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:34 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:34 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:34 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:34 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:34 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:34 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 13:53:34 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:34 --> length=2 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:35 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:35 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:35 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:35 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:35 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:35 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 13:53:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 13:53:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:35 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:39 --> choix id=8 vo=News ::> 
 Pipo.hx 108 choix
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:39 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:39 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:39 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:39 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:39 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:39 --> before ::> 
 TagManager.hx 133 getTaxoBySpodID
INFO - 2012-11-13 13:53:39 --> microbe.TagManager.getTags{} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:39 --> length=0 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:39 --> spod ::> 
 Api.hx 150 tags
INFO - 2012-11-13 13:53:39 --> spodnews ::> 
 Api.hx 155 tags
INFO - 2012-11-13 13:53:39 --> getSpoTablenews ::> 
 TagManager.hx 304 getSpodTable
INFO - 2012-11-13 13:53:39 --> spodablevo.News ::> 
 TagManager.hx 309 getSpodTable
INFO - 2012-11-13 13:53:39 --> managersys.db.Manager ::> 
 TagManager.hx 311 getSpodTable
INFO - 2012-11-13 13:53:39 --> spodTAble=actu ::> 
 TagManager.hx 93 getTaxos
INFO - 2012-11-13 13:53:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 101 getTaxos
INFO - 2012-11-13 13:53:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 160 tags
INFO - 2012-11-13 13:53:39 --> length=5 ::> 
 Api.hx 161 tags
INFO - 2012-11-13 13:53:41 --> ajoute ::> 
 Pipo.hx 271 ajoute
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:53:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-11-13 13:55:52 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:55:52 --> after ::> 
 Pipo.hx 168 index
INFO - 2012-11-13 13:57:18 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:57:18 --> after ::> 
 Pipo.hx 169 index
INFO - 2012-11-13 13:57:52 --> index ::> 
 Pipo.hx 161 index
INFO - 2012-11-13 13:57:52 --> after ::> 
 Pipo.hx 169 index
