<?php exit; ?>

INFO - 2013-04-14 14:03:49 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:03:50 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:04:37 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:04:37 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:04:46 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:04:46 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:04:46 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pokilolnnn
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:04:46 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:04:46 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:04:46 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:04:46 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:04:46 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:04:46 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:04:46 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:04:46 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:04:47 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:04:47 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:04:47 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:04:47 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:04:47 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:04:47 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:04:47 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:04:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:04:47 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:05:14 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:david</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:05:22 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:05:22 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:05:22 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:05:22 --> classMap=<div class='indent4'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:david</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 349 recClassMap
INFO - 2013-04-14 14:05:22 --> after ::> Api.hx 359 recClassMap
INFO - 2013-04-14 14:05:22 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviourtitre--david ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:05:22 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:05:22 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:05:22 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:05:22 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : david
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:05:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:05:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:05:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:05:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:05:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:05:23 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:05:23 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:05:23 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:05:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:05:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:05:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:05:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:05:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:05:23 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:05:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:05:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:05:23 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:06:12 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:06:12 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:06:26 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:06:26 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:06:26 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : david
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:26 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:06:26 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:06:26 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:06:26 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:06:26 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:06:26 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:06:26 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:06:26 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:06:26 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:06:26 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:06:26 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:06:26 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:06:26 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:06:26 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:06:26 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:06:26 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:06:26 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:06:31 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:barche</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:06:37 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:06:37 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:06:37 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:06:37 --> classMap=<div class='indent4'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:barche</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 349 recClassMap
INFO - 2013-04-14 14:06:37 --> after ::> Api.hx 359 recClassMap
INFO - 2013-04-14 14:06:37 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviourtitre--barche ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:06:37 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:06:37 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:06:37 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:06:37 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : barche
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:06:38 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:06:38 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:06:38 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:06:38 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:06:38 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:06:38 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:06:38 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:06:38 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:06:38 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:06:38 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:06:38 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:06:38 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:06:38 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:06:38 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:06:38 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:06:38 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:06:38 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:11:36 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:11:36 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:11:54 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:11:54 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:11:54 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : barche
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:54 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:11:54 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:11:54 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:11:54 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:11:54 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:11:54 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:11:54 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:11:54 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:11:54 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:11:54 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:11:54 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:11:54 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:11:54 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:11:54 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:11:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:11:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:11:54 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:11:56 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:11:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:zelote</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:12:02 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:12:02 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:12:02 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:12:02 --> classMap=<div class='indent4'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:zelote</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 349 recClassMap
INFO - 2013-04-14 14:12:02 --> PATATAtitre ::> Api.hx 351 recClassMap
INFO - 2013-04-14 14:12:02 --> after ::> Api.hx 362 recClassMap
INFO - 2013-04-14 14:12:02 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviourtitre--zelote ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:12:02 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:12:02 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:12:02 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:12:02 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : zelote
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:12:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:12:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:12:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:12:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:12:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:12:02 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:12:02 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:12:02 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:12:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:12:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:12:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:12:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:12:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:12:02 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:12:02 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:12:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:12:02 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:13:51 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:13:51 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:14:00 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:14:00 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:14:00 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : zelote
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:01 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:14:01 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:14:01 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:14:01 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:14:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:14:01 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:14:01 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:14:01 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:14:01 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:14:01 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:14:01 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:14:01 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:14:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:14:01 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:14:01 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:14:01 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:14:01 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:14:04 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:14:11 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:14:11 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:14:11 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:14:11 --> classMap=<div class='indent4'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 349 recClassMap
INFO - 2013-04-14 14:14:11 --> PATAATgrume ::> Api.hx 353 recClassMap
INFO - 2013-04-14 14:14:11 --> after ::> Api.hx 366 recClassMap
INFO - 2013-04-14 14:14:11 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviourtitre--grume ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:14:11 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:14:11 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:14:11 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:14:11 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:14:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:14:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:14:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:14:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:14:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:14:11 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:14:11 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:14:11 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:14:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:14:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:14:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:14:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:14:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:14:11 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:14:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:14:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:14:11 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:19:14 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:19:14 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:19:16 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:19:16 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:19:16 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:19:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:19:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:19:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:19:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:19:16 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:19:16 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:19:16 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:19:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:19:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:19:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:19:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:19:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:19:16 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:19:16 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:19:16 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:19:16 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:19:19 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:19:33 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:19:33 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:19:33 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:19:33 --> classMap=<div class='indent4'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 349 recClassMap
INFO - 2013-04-14 14:19:33 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:19:33 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:19:33 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:19:33 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:19:33 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:19:33 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:19:33 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:19:33 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:19:33 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:19:33 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:19:33 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:19:33 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:19:33 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:19:33 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:19:33 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:19:33 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:19:33 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:19:33 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:19:33 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:19:33 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:21:13 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:21:13 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:21:26 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:21:26 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:21:26 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:21:26 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:21:26 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:27 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:21:27 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:21:27 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:21:27 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:21:27 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:21:27 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:21:27 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:21:27 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:21:27 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:21:27 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:21:27 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:21:27 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:21:27 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:21:27 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:21:27 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:21:27 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:21:27 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:21:30 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:34 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:21:34 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:21:34 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:21:34 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:21:35 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:21:35 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:21:35 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:21:35 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:21:35 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:21:35 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:21:35 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:21:35 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:21:35 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:21:35 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:21:35 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:21:35 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:21:35 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:21:35 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:21:35 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:21:35 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:21:35 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:21:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:21:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:21:35 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:22:18 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:prass</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:22:23 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:22:23 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:22:23 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:22:23 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:22:23 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:22:23 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:22:24 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:22:24 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:22:24 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:22:24 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:22:24 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:22:24 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:22:24 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:22:24 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:22:24 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:22:24 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:22:24 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:22:24 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:22:24 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:22:24 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:22:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:22:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:22:24 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:24:30 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:24:30 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:24:39 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:24:39 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:24:39 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:40 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:24:40 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:24:40 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:24:40 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:24:40 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:24:40 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:24:40 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:24:40 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:24:40 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:24:40 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:24:40 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:24:40 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:24:40 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:24:40 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:24:40 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:24:40 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:24:40 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:24:43 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:24:51 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:24:51 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:24:51 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:24:51 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:24:51 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:24:51 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:24:51 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:24:51 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:24:51 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:24:51 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:24:51 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:24:51 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:24:51 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:24:51 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:24:51 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:24:51 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:24:51 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:24:51 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:24:51 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:24:51 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:24:51 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:24:51 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:24:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:24:51 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:26:37 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:26:37 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:26:39 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:26:39 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:26:39 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:40 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:26:40 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:26:40 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:26:40 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:26:40 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:26:40 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:26:40 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:26:40 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:26:40 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:26:40 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:26:40 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:26:40 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:26:40 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:26:40 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:26:40 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:26:40 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:26:40 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:26:42 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:26:56 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:26:56 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:26:56 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:26:56 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:26:56 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:26:56 --> PATAAT{actu#21} ::> Api.hx 355 recClassMap
INFO - 2013-04-14 14:27:24 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:27:24 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:27:34 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:27:34 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:27:34 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:27:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:27:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:27:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:27:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:27:34 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:27:34 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:27:34 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:27:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:27:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:27:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:27:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:27:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:27:34 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:27:34 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:27:34 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:27:34 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:27:39 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:27:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:27:44 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:27:44 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:27:44 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:27:44 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:27:44 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:28:08 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:28:08 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:28:17 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:28:17 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:28:17 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:28:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:28:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:28:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:28:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:28:18 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:28:18 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:28:18 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:28:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:28:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:28:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:28:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:28:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:28:18 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:28:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:28:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:28:18 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:28:19 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:28:35 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:grume</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:28:35 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:28:35 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:28:35 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:28:35 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:29:31 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:29:31 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:29:33 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:29:33 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:29:33 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:29:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:29:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:29:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:29:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:29:34 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:29:34 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:29:34 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:29:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:29:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:29:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:29:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:29:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:29:34 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:29:34 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:29:34 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:29:34 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:29:36 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:43 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:29:43 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:29:43 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:29:43 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:29:43 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:29:59 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:29:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:07 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:franche</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:30:07 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:30:07 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:30:07 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:30:07 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:30:34 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:30:34 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:30:36 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:30:36 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:30:36 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : grume
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:36 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:30:36 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:30:36 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:30:36 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:30:36 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:30:36 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:30:36 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:30:36 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:30:37 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:30:37 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:30:37 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:30:37 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:30:37 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:30:37 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:30:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:30:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:30:37 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:30:38 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:30:50 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:30:50 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:30:50 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:30:50 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:30:50 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:30:50 --> POUM ::> Api.hx 356 recClassMap
INFO - 2013-04-14 14:30:50 --> after ::> Api.hx 369 recClassMap
INFO - 2013-04-14 14:30:50 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviourtitre--test ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 14:30:50 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:30:50 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 14:32:27 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:32:28 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:32:30 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:32:30 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:32:30 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:32:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:32:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:32:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:32:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:32:31 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:32:31 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:32:31 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:32:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:32:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:32:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:32:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:32:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:32:31 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:32:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:32:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:32:31 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:32:34 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:32:39 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:32:39 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:32:39 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:32:39 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:32:39 --> POUM ::> Api.hx 356 recClassMap
INFO - 2013-04-14 14:32:39 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:32:39 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:32:39 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:32:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:32:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:32:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:32:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:32:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:32:39 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:32:39 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:32:39 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:32:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:32:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:32:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:32:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:32:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:32:39 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:32:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:32:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:32:39 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:33:26 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:33:26 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:33:28 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:33:28 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:33:28 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:29 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:33:29 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:33:29 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:33:29 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:33:29 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:33:29 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:33:29 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:33:29 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:33:29 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:33:29 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:33:29 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:33:29 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:33:29 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:33:29 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:33:29 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:33:29 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:33:29 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:33:30 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:33:38 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:33:38 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:33:38 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:33:38 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:33:38 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:33:38 --> POUM ::> Api.hx 356 recClassMap
INFO - 2013-04-14 14:39:07 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:39:07 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:39:09 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:39:09 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:39:09 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:39:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:39:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:39:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:39:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:39:09 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:39:09 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:39:09 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:39:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:39:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:39:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:39:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:39:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:39:09 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:39:09 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:39:09 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:39:09 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:39:11 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:39:17 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:39:17 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:39:17 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:39:17 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:39:17 --> POUM ::> Api.hx 356 recClassMap
INFO - 2013-04-14 14:39:17 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:39:17 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:39:17 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:39:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:39:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:39:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:39:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:39:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:39:18 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:39:18 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:39:18 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:39:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:39:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:39:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:39:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:39:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:39:18 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:39:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:39:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:39:18 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:54:46 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:54:46 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:54:48 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:54:48 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:54:48 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:54:49 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:54:49 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:54:49 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:54:49 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:54:49 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:54:49 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:54:49 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:54:49 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:54:49 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:54:49 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:54:49 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:54:49 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:54:49 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:54:49 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:54:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:54:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:54:49 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:55:02 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:11 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:55:11 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:55:11 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:55:11 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:55:11 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:55:51 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:55:51 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:55:58 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:55:58 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:55:58 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:55:59 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:55:59 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:55:59 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:55:59 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:55:59 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:55:59 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:55:59 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:55:59 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:55:59 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:55:59 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:55:59 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:55:59 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:55:59 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:55:59 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:55:59 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:55:59 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:55:59 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:56:03 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:56:08 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:56:08 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:56:08 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:56:08 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:56:08 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:57:44 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:57:44 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 14:57:47 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:57:47 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:57:47 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:48 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:57:48 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:57:48 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:57:48 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:57:48 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:57:48 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:57:48 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:57:48 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:57:48 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:57:48 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:57:48 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:57:48 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:57:48 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:57:48 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:57:48 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:57:48 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:57:48 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:57:54 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:57:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 14:58:01 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 14:58:01 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 14:58:01 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 14:58:01 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 14:58:01 --> PATAATsys.db._Mysql.MysqlResultSet ::> Api.hx 356 recClassMap
INFO - 2013-04-14 14:58:01 --> POUM ::> Api.hx 357 recClassMap
INFO - 2013-04-14 14:58:01 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 14:58:01 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 14:58:01 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 14:58:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:58:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:58:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:58:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:58:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:58:02 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 14:58:02 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 14:58:02 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 14:58:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 14:58:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 14:58:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 14:58:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 14:58:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 14:58:02 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 14:58:02 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 14:58:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 14:58:02 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 14:59:59 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 14:59:59 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:00:01 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:00:01 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:00:01 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:00:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:00:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:00:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:00:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:00:11 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:00:11 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:00:11 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:00:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:00:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:00:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:00:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:00:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:00:11 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:00:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:00:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:00:11 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:00:14 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:00:19 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:00:19 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:00:19 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:00:19 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:00:19 --> POUM ::> Api.hx 358 recClassMap
INFO - 2013-04-14 15:00:19 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:00:19 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:00:19 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:00:19 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:00:19 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:00:19 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:00:19 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:00:19 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:00:19 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:00:19 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:00:19 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:00:20 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:00:20 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:00:20 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:00:20 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:00:20 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:00:20 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:00:20 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:00:20 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:00:20 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:01:01 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:01:01 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:01:04 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:01:04 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:01:04 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:05 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:01:05 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:01:05 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:01:05 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:01:05 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:01:05 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:01:05 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:01:05 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:01:05 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:01:05 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:01:05 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:01:05 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:01:05 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:01:05 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:01:05 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:01:05 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:01:05 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:01:09 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:01:14 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:01:14 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:01:14 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:01:14 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:01:14 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:01:14 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:01:14 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:01:14 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:01:15 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:01:15 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:01:15 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:01:15 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:01:15 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:01:15 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:01:15 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:01:15 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:01:15 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:01:15 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:01:15 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:01:15 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:01:15 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:01:15 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:01:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:01:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:01:15 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:10:26 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:10:26 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:10:28 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:10:28 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:10:28 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:29 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:10:29 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:10:29 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:10:29 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:10:29 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:10:29 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:10:29 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:10:29 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:10:29 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:10:29 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:10:29 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:10:29 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:10:29 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:10:29 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:10:29 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:10:29 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:10:29 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:10:34 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:10:43 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:10:43 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:10:43 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:10:43 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:10:43 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:10:43 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:10:43 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:10:43 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:10:45 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:10:45 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:10:45 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:10:45 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:10:45 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:10:45 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:10:45 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:10:45 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:10:45 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:10:45 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:10:45 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:10:45 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:10:45 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:10:45 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:10:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:10:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:10:45 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:11:14 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:11:14 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:11:17 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:11:17 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:11:17 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:11:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:11:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:11:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:11:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:11:18 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:11:18 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:11:18 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:11:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:11:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:11:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:11:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:11:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:11:18 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:11:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:11:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:11:18 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:11:20 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:27 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:11:27 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:11:27 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:11:27 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:11:27 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:11:27 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:11:40 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:11:52 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:carabosse</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:11:52 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:11:52 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:11:52 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:11:52 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:11:52 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:14:09 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:14:09 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:14:32 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:14:32 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:14:34 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:14:34 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:14:34 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:14:35 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:14:35 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:14:35 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:14:35 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:14:35 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:14:35 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:14:35 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:14:35 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:14:35 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:14:35 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:14:35 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:14:35 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:14:35 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:14:35 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:14:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:14:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:14:35 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:14:44 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:22ElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:banjo</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:1970-01-01</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:14:44 --> record22 ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:14:44 --> map.id!=null ::> Api.hx 336 recClassMap
INFO - 2013-04-14 15:14:44 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 15:14:44 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviourtitre--banjo ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviourdate--1970-01-01 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:14:44 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:14:44 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:15:51 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:15:51 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:15:53 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:15:53 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:15:53 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:15:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : banjo
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:54 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:15:54 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:15:54 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:15:54 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:15:54 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:15:54 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:15:54 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:15:54 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:15:54 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:15:54 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:15:54 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:15:54 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:15:54 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:15:54 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:15:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:15:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:15:54 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:15:56 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:15:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:08 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:jean jacque</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:16:08 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:16:08 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:16:08 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:16:08 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:16:08 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:16:20 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:16:29 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:rachmanikov</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:16:29 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:16:30 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:16:30 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:16:30 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:16:30 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:17:14 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:17:14 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:17:16 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:17:16 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:17:16 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : banjo
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:17 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:17:17 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:17:17 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:17:17 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:17:17 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:17:17 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:17:17 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:17:17 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:17:17 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:17:17 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:17:17 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:17:17 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:17:17 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:17:17 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:17:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:17:17 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:17:17 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:17:20 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:17:30 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:timtomtam</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:17:30 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:17:30 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:17:30 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:17:30 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:17:30 --> pip=sys.db._Mysql.MysqlResultSet ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:18:47 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:18:47 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:18:49 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:18:49 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:18:49 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : banjo
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:50 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:18:50 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:18:50 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:18:50 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:18:50 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:18:50 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:18:50 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:18:50 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:18:50 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:18:50 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:18:50 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:18:50 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:18:50 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:18:50 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:18:50 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:18:50 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:18:50 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:18:59 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:18:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:07 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:envole moi</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:19:07 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:19:07 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:19:07 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:19:07 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:19:07 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:19:07 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 15:19:07 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviourtitre--envole moi ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:19:07 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:07 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:19:53 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:19:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:03 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:20:03 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:20:03 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:20:03 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:20:03 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:20:03 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:20:06 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:20:16 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:catastrophe</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:20:16 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:20:16 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:20:16 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:20:16 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:20:16 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:20:16 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 15:20:16 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviourtitre--catastrophe ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:20:16 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:20:16 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:40 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:27:40 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:27:47 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:27:47 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:27:47 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : catastrophe
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:47 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:27:47 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:27:47 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:27:47 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:27:47 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:27:47 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:27:47 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:27:47 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:27:47 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:27:47 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:27:47 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:27:47 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:27:47 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:27:47 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:27:47 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:27:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:27:47 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:27:50 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:black keys</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:27:57 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:27:57 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:27:57 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:27:57 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:27:57 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:27:57 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 15:27:57 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviourtitre--black keys ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:27:57 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:27:57 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:27:57 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:27:57 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : black keys
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:27:57 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:27:57 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:27:57 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:27:57 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:27:57 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:27:57 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:27:57 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:27:57 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:27:57 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:27:57 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:27:57 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:27:57 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:27:57 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:27:57 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:27:57 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:27:57 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:27:57 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:14 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:29:14 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:29:16 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:29:16 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:29:16 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : black keys
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:16 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:29:17 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:17 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:17 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:17 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:17 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:17 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:17 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:17 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:29:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:29:17 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:17 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:19 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:everlasting live</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:29:28 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:29:28 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:29:28 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:29:28 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:29:28 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:29:28 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 15:29:28 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviourtitre--everlasting live ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 15:29:28 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 15:29:28 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:29:28 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:29:28 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : everlasting live
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:28 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:29:28 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:28 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:28 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:29:28 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:29:28 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:28 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:32 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:29:37 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:29:37 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:29:37 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:29:37 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:29:37 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:29:37 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:29:37 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:29:37 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : everlasting live
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:29:37 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:37 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:37 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:37 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:37 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:37 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:29:37 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:37 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:29:38 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:29:38 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:29:38 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:29:38 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:29:38 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:29:38 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:29:38 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:29:38 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:29:38 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:40:50 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:40:50 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:40:52 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:40:52 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:40:52 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : everlasting live
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:52 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:40:52 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:40:52 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:40:52 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:40:52 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:40:52 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:40:52 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:40:52 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:40:53 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:40:53 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:40:53 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:40:53 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:40:53 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:40:53 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:40:53 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:40:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:40:53 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:40:57 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:40:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:07 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:41:07 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:41:07 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:41:07 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:41:07 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:41:07 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:41:45 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:41:45 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 15:41:47 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 15:41:47 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 15:41:47 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : everlasting live
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:48 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:41:48 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:41:48 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:41:48 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:41:48 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:41:48 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 15:41:48 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 15:41:48 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 15:41:48 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 15:41:48 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 15:41:48 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 15:41:48 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 15:41:48 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 15:41:48 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 15:41:48 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 15:41:48 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 15:41:48 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 15:41:53 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 15:41:58 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 15:41:58 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 15:41:58 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 15:41:58 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 15:41:58 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 15:41:58 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 15:46:35 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 15:46:35 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:04:33 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:04:33 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:04:39 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:04:39 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:04:39 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : everlasting live
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:04:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:04:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:04:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:04:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:04:39 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:04:39 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:04:39 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:04:40 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:04:40 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:04:40 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:04:40 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:04:40 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:04:40 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:04:40 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:04:40 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:04:40 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:04:43 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:04:50 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:noisette</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:04:50 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:04:50 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:04:50 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:04:50 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:04:50 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:04:50 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:04:50 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviourtitre--noisette ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:04:50 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:04:50 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:17 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:06:17 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:06:23 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:06:23 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:06:23 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : noisette
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:06:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:06:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:06:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:06:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:06:23 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:06:23 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:06:23 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:06:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:06:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:06:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:06:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:06:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:06:23 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:06:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:06:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:06:23 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:06:25 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:06:32 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:lupinlupin</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:06:32 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:06:32 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:06:32 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:06:32 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:06:32 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:06:32 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:06:32 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviourtitre--lupinlupin ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:06:32 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:06:32 --> fullSpodactu#28 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:09:10 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:09:11 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:09:12 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:09:12 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:09:12 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : lupinlupin
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:13 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:09:13 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:09:13 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:09:13 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:09:13 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:09:13 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:09:13 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:09:13 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:09:13 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:09:13 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:09:13 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:09:13 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:09:13 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:09:13 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:09:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:09:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:09:13 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:09:14 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:20 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:internet</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:09:20 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:09:20 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:09:20 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:09:20 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:09:20 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:09:20 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:09:20 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviourtitre--internet ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:20 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:20 --> fullSpodactu#29 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:09:33 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:09:46 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:bunikop</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:09:46 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:09:46 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:09:46 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:09:46 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:09:46 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:09:46 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:09:46 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviourtitre--bunikop ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:09:46 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:09:46 --> fullSpodactu#30 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:10:52 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:10:52 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:10:54 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:10:54 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:10:54 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bunikop
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:10:55 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:10:55 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:10:55 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:10:55 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:10:55 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:10:55 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:10:55 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:10:55 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:10:55 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:10:55 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:10:55 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:10:55 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:10:55 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:10:55 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:10:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:10:55 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:10:55 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:11:02 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:11:21 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:azerty</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:11:21 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:11:21 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:11:21 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:11:21 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:11:21 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:11:21 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:11:21 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviourtitre--azerty ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:11:21 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:11:21 --> fullSpodactu#31 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:12:25 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:12:25 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:12:27 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:12:27 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:12:27 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : azerty
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:12:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:12:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:12:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:12:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:12:28 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:12:28 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:12:28 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:12:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:12:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:12:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:12:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:12:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:12:28 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:12:28 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:12:28 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:12:28 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:12:30 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:12:37 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:ethos</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:12:37 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:12:37 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:12:37 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:12:37 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:12:37 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:12:37 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:12:37 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviourtitre--ethos ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:12:37 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:12:37 --> fullSpodactu#32 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:13:16 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:13:16 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:13:18 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:13:18 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:13:18 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : ethos
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:13:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:13:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:13:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:13:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:13:18 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:13:18 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:13:18 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:13:18 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:13:18 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:13:18 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:13:18 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:13:18 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:13:18 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:13:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:13:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:13:18 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:13:20 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:26 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:essentiel</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:13:26 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:13:27 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:13:27 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:13:27 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:13:27 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:13:27 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:13:27 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviourtitre--essentiel ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:27 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:27 --> fullSpodactu#33 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:13:45 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:13:54 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:samerre</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:13:54 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:13:54 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:13:54 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:13:54 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:13:54 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:13:54 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:13:54 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviourtitre--samerre ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:13:54 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:13:54 --> fullSpodactu#34 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:16:40 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:16:40 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:16:41 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:16:41 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:16:41 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : samerre
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:42 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:16:42 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:16:42 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:16:42 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:16:42 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:16:42 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:16:42 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:16:42 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:16:42 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:16:42 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:16:42 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:16:42 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:16:42 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:16:42 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:16:42 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:16:42 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:16:42 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:16:44 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:16:54 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:sexisme</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:16:54 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:16:54 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:16:54 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:16:54 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:16:54 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:16:54 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:16:54 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviourtitre--sexisme ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:16:54 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:16:54 --> fullSpodactu#35 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:17:20 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:17:27 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:varter</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:17:27 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:17:27 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:17:27 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:17:27 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:17:27 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:17:27 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:17:27 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviourtitre--varter ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:17:27 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:17:27 --> fullSpodactu#36 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:18:06 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:18:07 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:18:08 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:18:08 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:18:08 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : varter
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:09 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:18:09 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:09 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:18:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:09 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:18:09 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:18:09 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:09 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:18:11 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:18 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:jai po</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:18:18 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:18:18 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:18:18 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:18:18 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:18:18 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:18:18 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:18:18 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviourtitre--jai po ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:18 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:18 --> fullSpodactu#37 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:18:42 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:18:42 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:18:44 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:18:44 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:18:44 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : jai po
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:44 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:44 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:44 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:44 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:44 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:44 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:18:44 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:44 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:18:45 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:45 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:45 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:45 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:45 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:45 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:18:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:18:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:45 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:18:49 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:femineen</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:18:56 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:18:56 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:18:56 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:18:56 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:18:56 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:18:56 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:18:56 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviourtitre--femineen ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:18:56 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:18:56 --> fullSpodactu#38 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:18:56 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:18:56 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:18:56 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : femineen
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:18:58 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:58 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:58 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:58 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:58 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:58 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:18:58 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:58 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:18:58 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:18:58 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:18:58 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:18:58 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:18:58 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:18:58 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:18:58 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:18:58 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:18:58 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:19:03 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:09 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:19:09 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:19:09 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:19:09 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:19:09 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:19:09 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:19:16 --> map=<div class='indent6'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimule</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:19:16 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:19:16 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:19:16 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:19:16 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:19:16 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:19:16 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:19:16 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviourtitre--pimule ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:19:16 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:19:16 --> fullSpodactu#39 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:19:16 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:19:16 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:19:16 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimule
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:19:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:19:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:19:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:19:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:19:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:19:16 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:19:16 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:19:16 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:19:17 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:19:17 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:19:17 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:19:17 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:19:17 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:19:17 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:19:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:19:17 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:19:17 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:45:36 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:45:36 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:45:38 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:45:38 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:45:38 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimule
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:38 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:45:38 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:45:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:45:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:45:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:45:39 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:45:39 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:45:39 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:45:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:45:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:45:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:45:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:45:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:45:39 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:45:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:45:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:45:39 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:45:41 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:45:47 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimule</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:45:47 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:45:47 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:45:47 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:45:47 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:45:47 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:46:38 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:46:38 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:46:40 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:46:40 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:46:40 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimule
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:41 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:46:41 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:46:41 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:46:41 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:46:41 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:46:41 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:46:41 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:46:41 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:46:41 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:46:41 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:46:41 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:46:41 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:46:41 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:46:41 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:46:41 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:46:41 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:46:41 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:46:50 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:46:56 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimule</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:46:56 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:46:56 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:46:56 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:46:56 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:46:56 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:48:57 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:48:58 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:49:00 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:49:00 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:49:00 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimule
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:00 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:49:00 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:49:00 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:49:00 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:49:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:49:01 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:49:01 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:49:01 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:49:01 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:49:01 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:49:01 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:49:01 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:49:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:49:01 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:49:01 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:49:01 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:49:01 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:49:03 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:49:08 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimule</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:49:08 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:49:08 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:49:08 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:49:08 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:49:08 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:50:36 --> index ::> Pipo.hx 171 index
INFO - 2013-04-14 17:50:36 --> after ::> Pipo.hx 179 index
INFO - 2013-04-14 17:50:39 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:50:39 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:50:39 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimule
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:50:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:50:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:50:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:50:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:50:39 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:50:39 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:50:39 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:50:39 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:50:39 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:50:39 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:50:39 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:50:39 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:50:39 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:50:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:50:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:50:39 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-14 17:50:44 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:50:50 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimule</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:50:50 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:50:50 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:50:50 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:50:50 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:50:50 --> pip=1 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:51:01 --> map=<div class='indent6'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pimulez</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-14</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-14 17:51:01 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-14 17:51:01 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-14 17:51:01 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-14 17:51:01 --> found unique KEY ::> Api.hx 352 recClassMap
INFO - 2013-04-14 17:51:01 --> pip=0 ::> Api.hx 355 recClassMap
INFO - 2013-04-14 17:51:01 --> after ::> Api.hx 375 recClassMap
INFO - 2013-04-14 17:51:01 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviourtitre--pimulez ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviourdate--2013-04-14 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-14 17:51:01 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-14 17:51:01 --> fullSpodactu#40 ::> Api.hx 395 recClassMap
INFO - 2013-04-14 17:51:01 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-14 17:51:01 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-14 17:51:01 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pimulez
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-14 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-14 17:51:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:51:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:51:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:51:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:51:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:51:02 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-14 17:51:02 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-14 17:51:02 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-14 17:51:02 --> spod ::> Api.hx 150 tags
INFO - 2013-04-14 17:51:02 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-14 17:51:02 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-14 17:51:02 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-14 17:51:02 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-14 17:51:02 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-14 17:51:02 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-14 17:51:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-14 17:51:02 --> length=5 ::> Api.hx 161 tags
