<?php exit; ?>

INFO - 2012-09-24 09:12:25 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-24 09:12:26 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-24 09:12:28 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 09:12:28 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 09:12:28 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:12:28 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:12:28 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:12:28 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:12:28 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:12:28 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:12:28 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:12:29 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:12:29 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:12:29 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:12:29 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:12:29 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:12:29 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 09:12:29 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 09:12:29 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:22:47 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-24 09:22:47 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-24 09:22:49 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 09:22:49 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 09:22:49 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:22:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:22:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:22:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:22:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:22:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:22:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:22:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:22:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:22:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:22:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:22:49 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 09:22:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 09:22:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:22:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:23:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:23:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:23:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:23:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:23:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:23:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:23:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:23:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:23:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:23:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:23:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:23:00 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 09:23:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 09:23:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:24:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 09:25:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:25:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:25:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:25:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:25:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:25:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 09:25:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 09:25:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 09:25:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 09:25:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 09:25:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 09:25:00 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 09:25:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 09:25:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:18:57 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:18:57 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:18:57 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:18:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:18:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:18:57 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:18:57 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:18:57 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:18:57 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:18:58 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:18:58 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:18:58 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:18:58 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:18:58 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:18:58 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:18:58 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:18:58 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:22:17 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:22:17 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:22:17 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:22:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:22:18 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:22:18 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:22:18 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:22:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:22:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:22:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:22:18 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:22:18 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:22:18 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:22:18 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:22:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:22:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:22:48 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:22:48 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:22:48 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:22:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:22:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:22:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:22:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:22:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:22:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:22:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:22:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:22:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:22:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:22:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:22:49 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:22:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:22:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:23:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:24:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:53 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-24 10:30:53 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-24 10:30:55 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:30:55 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:30:55 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:30:56 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:30:56 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:30:56 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:30:56 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:30:56 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:30:56 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:30:56 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:30:56 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:30:56 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:30:56 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:30:56 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:30:56 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:30:56 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:30:56 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:31:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:33:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:42:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:42:53 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:42:53 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:42:53 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:42:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:42:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:42:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:42:53 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:42:53 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:42:53 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:42:53 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:42:53 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:42:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:42:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:42:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:05 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:43:05 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:43:05 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:43:05 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:43:05 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:43:05 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:43:05 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:43:05 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:43:05 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:43:05 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:43:05 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:43:05 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:43:05 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:43:05 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:43:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:47:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:47:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:47:15 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:47:15 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:47:15 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:47:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:47:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:47:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:47:15 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:47:15 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:47:15 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:47:15 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:47:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:47:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:54:11 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-24 10:54:12 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-24 10:54:20 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:54:20 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:54:20 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:54:21 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:54:21 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:54:21 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:54:21 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:54:21 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:54:21 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:54:21 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:54:21 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:54:21 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:54:21 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:54:21 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:54:21 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:54:21 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:54:21 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test eng</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-24</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-24 10:55:39 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-24 10:55:39 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-24 10:55:39 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviourtitre--test eng ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviourdate--2012-09-24 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviourcontenu-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:55:39 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:55:39 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:55:39 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:55:39 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test eng
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:39 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:39 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:39 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:39 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:40 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:40 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:40 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:40 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:40 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:55:40 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:55:40 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> choix id=3 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test eng
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:45 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:45 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:45 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:45 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:46 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:46 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:46 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:46 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:46 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:46 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:55:46 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:55:46 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:48 --> choix id=3 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test eng
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:49 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:49 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:55:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:55:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:50 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:51 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:51 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:51 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:55:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:55:51 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:55:51 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:55:51 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:55:51 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:55:51 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:55:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:55:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> choix id=3 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test eng
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:04 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:56:04 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:56:04 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:56:04 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:56:04 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:56:04 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:56:04 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:56:04 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:56:04 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:56:04 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:56:04 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:56:04 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:56:04 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:56:04 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:56:05 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:56:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:56:06 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:56:06 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:56:06 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:56:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:56:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:56:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:56:06 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:56:06 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:56:06 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:56:06 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:56:06 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:56:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:56:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:34 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-24 10:58:34 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-24 10:58:36 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:58:36 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:58:36 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test eng
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:37 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:37 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:37 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:37 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:37 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:37 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:37 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:37 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:58:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:58:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:39 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:39 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:39 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:39 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:39 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:39 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:39 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:39 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:58:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:58:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:shakira test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-24</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:2</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-24 10:58:49 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-24 10:58:49 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-24 10:58:49 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviourtitre--shakira test ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviourdate--2012-09-24 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviourcontenu-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 10:58:49 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 10:58:49 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 10:58:49 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:58:49 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : shakira test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:50 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:50 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:50 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:50 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:50 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:50 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:50 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:50 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:50 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:50 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:50 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:50 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:58:50 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:58:50 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:54 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:54 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:54 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:54 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:54 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:54 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:54 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:54 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:54 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:54 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:54 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:54 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:58:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:58:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : shakira test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 10:58:56 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:56 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:56 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:56 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:56 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:56 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 10:58:56 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 10:58:56 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 10:58:56 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 10:58:56 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 10:58:56 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 10:58:56 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 10:58:56 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 10:58:56 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:35:53 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 12:35:53 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 12:35:55 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:35:55 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:35:55 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : shakira test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:35:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:17 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 12:36:18 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 12:36:19 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:36:19 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:36:19 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : shakira test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:36:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:36:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:36:19 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:36:19 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:36:19 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:36:19 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:36:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:36:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:36:19 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:36:19 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:36:19 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:36:19 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 12:36:19 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 12:36:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:00 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 12:37:00 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 12:37:01 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:37:01 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:37:01 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : shakira test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:02 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:02 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:02 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:02 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:02 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:02 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:02 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:02 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:02 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:02 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:02 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:02 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 12:37:02 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 12:37:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:04 --> ajoute ::> 
 Pipo.hx 257 ajoute
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:franche</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-24</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-24 12:37:09 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-24 12:37:09 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-24 12:37:09 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviourtitre--franche ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviourdate--2012-09-24 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviourcontenu-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:09 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:09 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:37:09 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:37:09 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:09 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:09 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:09 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:09 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:09 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:09 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:10 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:10 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:10 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:10 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 12:37:10 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 12:37:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:17 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:english</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-24</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:5</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-24 12:37:17 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-24 12:37:17 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-24 12:37:17 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviourtitre--english ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviourdate--2012-09-24 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviourcontenu-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 12:37:18 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 12:37:18 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:37:18 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:37:18 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:37:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:18 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:18 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:18 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:18 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:37:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:37:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:37:19 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-24 12:37:19 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-24 12:37:19 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-24 12:37:19 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-24 12:37:19 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-24 12:37:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:16 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 12:58:16 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 12:58:18 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 12:58:18 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:58:18 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:18 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:18 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:18 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:18 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:19 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:19 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:19 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:19 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 12:58:19 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 12:58:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:23 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:24 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:24 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:24 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:24 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:24 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:24 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:24 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:24 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 12:58:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 12:58:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:35 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:35 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:35 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:35 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:35 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:35 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:35 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:35 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 12:58:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 12:58:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 12:58:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:39 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:39 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:39 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:39 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 12:58:40 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 12:58:40 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 12:58:40 --> getSpoTablenews ::> 
 TagManager.hx 282 getSpodTable
INFO - 2012-09-24 12:58:40 --> spodablevo.News ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 12:58:40 --> managersys.db.Manager ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 12:58:40 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 12:58:40 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 12:58:40 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:00:00 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:00:00 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:00:04 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:00:04 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:00:04 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:00:04 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:00:04 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:00:04 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:00:04 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:00:04 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:00:04 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:00:04 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:00:04 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:00:04 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:00:04 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:00:04 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:00:04 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:00:04 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:00:04 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:01:02 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:01:02 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:01:11 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:01:11 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:01:11 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:11 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:01:11 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:01:11 --> getTAxoBySpodID ::> 
 TagManager.hx 107 getTaxoBySpodID
INFO - 2012-09-24 13:01:11 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:01:11 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:01:11 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:01:11 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:01:12 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:01:12 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:01:12 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:01:12 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:01:12 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:01:12 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:01:12 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:01:12 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:01:42 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:01:42 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:01:44 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:01:44 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:01:44 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:01:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:01:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:01:45 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:01:45 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:01:45 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:01:45 --> getTAxoBySpodID ::> 
 TagManager.hx 110 getTaxoBySpodID
INFO - 2012-09-24 13:01:45 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:01:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:01:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:01:45 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:01:45 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:01:45 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:01:45 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:01:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:01:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:02:45 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:02:45 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:02:51 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:02:51 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:02:51 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:02:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:02:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:02:51 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:02:51 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:02:51 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:03:10 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:03:10 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:03:10 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:03:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:03:10 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:03:10 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:03:10 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:03:17 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:03:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:03:18 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:03:18 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:03:18 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:03:21 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:21 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:03:21 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:03:21 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:03:21 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:03:21 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:03:23 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:03:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:03:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:03:23 --> getSpoTablenews ::> 
 TagManager.hx 283 getSpodTable
INFO - 2012-09-24 13:03:23 --> spodablevo.News ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:03:23 --> managersys.db.Manager ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:05:51 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:05:51 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:05:57 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:05:57 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:05:57 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:05:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:05:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:05:57 --> getSpoTablenews ::> 
 TagManager.hx 285 getSpodTable
INFO - 2012-09-24 13:05:57 --> spodablevo.News ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:05:57 --> managersys.db.Manager ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:06:08 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:06:08 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:06:08 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:08 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:06:08 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:06:08 --> getSpoTablenews ::> 
 TagManager.hx 285 getSpodTable
INFO - 2012-09-24 13:06:08 --> spodablevo.News ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:06:08 --> managersys.db.Manager ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> choix id=6 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:13 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:06:13 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:06:13 --> getSpoTablenews ::> 
 TagManager.hx 285 getSpodTable
INFO - 2012-09-24 13:06:13 --> spodablevo.News ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:06:13 --> managersys.db.Manager ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:06:14 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:06:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:06:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:06:15 --> getSpoTablenews ::> 
 TagManager.hx 285 getSpodTable
INFO - 2012-09-24 13:06:15 --> spodablevo.News ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 13:06:15 --> managersys.db.Manager ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:52:14 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:52:14 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:52:23 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:52:23 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:52:23 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:52:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:52:24 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:52:24 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:52:24 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:52:55 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:52:56 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:52:56 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:52:56 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:52:56 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:52:56 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:52:56 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:52:56 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:24 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:55:24 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:55:30 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:55:30 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:55:30 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:31 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:55:31 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:55:31 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:55:31 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:55:31 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:31 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:55:31 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:55:31 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:55:31 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:55:31 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:55:31 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:31 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:55:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:55:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:55:41 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:55:41 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:55:42 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:55:42 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:55:42 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:42 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:55:42 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:55:42 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:55:42 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:55:42 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:49 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:55:49 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:55:52 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:55:52 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:55:52 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:55:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:55:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:55:53 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:55:53 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:55:53 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:53 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:55:53 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:55:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:55:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:55:53 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:55:53 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:55:53 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:55:53 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:55:53 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:55:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:40 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:56:40 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:56:44 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:56:44 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:56:44 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:56:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:47 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:47 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:47 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:47 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:47 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:47 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:56:47 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:47 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:47 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:47 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:47 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:47 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:47 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:56:47 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:56:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:51 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:51 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:51 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:51 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:51 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:56:51 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:52 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:52 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:52 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:52 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:52 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:52 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:56:52 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:56:52 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:56:54 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:54 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:54 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:54 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:54 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:54 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:56:54 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:56:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:56:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:56:55 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:56:55 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:56:55 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:56:55 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:56:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:56:55 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:58:15 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:58:15 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:58:18 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:58:18 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:58:18 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:58:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:58:19 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:58:19 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:58:19 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:58:19 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:58:19 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:58:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:58:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:58:19 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:58:19 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:58:19 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:58:19 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:58:19 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:58:19 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:58:23 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:58:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:58:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:58:23 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:58:23 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:58:23 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:58:23 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:58:23 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:58:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:58:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:58:23 --> getSpoTablenews ::> 
 TagManager.hx 287 getSpodTable
INFO - 2012-09-24 13:58:23 --> spodablevo.News ::> 
 TagManager.hx 292 getSpodTable
INFO - 2012-09-24 13:58:23 --> managersys.db.Manager ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 13:58:23 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:58:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:58:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:27 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 13:59:27 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 13:59:32 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 13:59:32 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:59:32 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:36 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:36 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:36 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:36 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:36 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:36 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:59:36 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:37 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:37 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:37 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:37 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:59:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:59:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:40 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:41 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:41 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:41 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:41 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:41 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:41 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:59:41 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:41 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:41 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:41 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:41 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:41 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:41 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:59:41 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:59:41 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 13:59:44 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:44 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:44 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:44 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:44 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:44 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 13:59:44 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 13:59:44 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 13:59:44 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 13:59:44 --> getSpoTablenews ::> 
 TagManager.hx 288 getSpodTable
INFO - 2012-09-24 13:59:44 --> spodablevo.News ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 13:59:44 --> managersys.db.Manager ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 13:59:44 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 13:59:44 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 13:59:44 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:00:18 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:00:18 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:00:43 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:00:43 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:00:43 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:00:43 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:00:43 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:00:43 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:00:43 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:00:43 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:00:43 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:00:43 --> istraductable ::> 
 TagManager.hx 119 getTaxoBySpodID
INFO - 2012-09-24 14:00:43 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:00:43 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:00:43 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:00:43 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:00:43 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:00:43 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:00:43 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:00:43 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:00:43 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:01:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:01:39 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:01:39 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:01:39 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:01:39 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:01:39 --> istraductable ::> 
 TagManager.hx 119 getTaxoBySpodID
INFO - 2012-09-24 14:01:39 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:01:39 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:01:39 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:01:39 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:01:39 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:01:39 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:01:39 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:01:39 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:01:39 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:01:42 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:01:42 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:01:42 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:01:42 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:01:42 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:01:42 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:01:42 --> istraductable ::> 
 TagManager.hx 119 getTaxoBySpodID
INFO - 2012-09-24 14:01:42 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:01:42 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:01:42 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:01:42 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:01:42 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:01:42 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:01:42 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:01:42 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:01:42 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:02:08 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:02:08 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:02:17 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:02:17 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:02:25 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:02:25 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:02:25 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:02:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:02:25 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:02:25 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:02:25 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:02:25 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:02:25 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:02:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:02:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:02:25 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:02:25 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:02:25 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:02:25 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:02:25 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:02:25 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:02:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> choix id=6 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:00 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:00 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:00 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:00 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:03:00 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:00 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:00 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:00 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:00 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:03:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:03:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:popop</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-24</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:6</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-24 14:03:06 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-24 14:03:06 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-24 14:03:06 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviourtitre--popop ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviourdate--2012-09-24 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviourcontenu-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-24 14:03:06 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-24 14:03:06 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:03:06 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:03:06 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:07 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:07 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:07 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:07 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:07 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:07 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:03:07 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:07 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:07 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:07 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:07 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:07 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:07 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:03:07 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:03:07 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:09 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:10 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:10 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:10 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:10 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:03:10 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:10 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:10 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:10 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:10 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:03:10 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:03:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:03:12 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:12 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:12 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:12 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:12 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:12 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:03:12 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:03:12 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:03:12 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:03:12 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:03:12 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:03:12 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:03:12 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:03:12 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:03:12 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:03 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:06:04 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:06:05 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:06:05 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:06:05 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:05 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:06 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:06 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:06 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:06 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:06:06 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:06 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:06 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:06 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:06 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:06:06 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:06:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:09 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:09 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:09 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:09 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:09 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:09 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:09 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:06:09 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:09 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:09 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:09 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:09 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:09 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:09 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:06:09 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:06:09 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:11 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:11 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:11 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:11 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:11 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:11 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:06:11 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:11 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:11 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:11 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:06:11 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:06:11 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:06:11 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:06:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:06:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:54 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:06:55 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:06:56 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:06:56 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:06:56 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:06:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:57 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:06:57 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:06:57 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:06:57 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:06:57 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:06:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:06:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:06:57 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:06:57 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:06:57 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:06:57 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:06:57 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:06:57 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:06 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:06 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:06 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:06 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:06 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:07:06 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:06 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:06 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:06 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:06 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:07:06 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:07:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:13 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:13 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:13 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:13 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:13 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:13 --> spodableid= ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:07:13 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:13 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:13 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:13 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:13 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:13 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:13 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:07:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:07:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:50 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:07:50 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:07:54 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:07:54 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:07:54 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:07:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:55 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:55 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:55 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:55 --> spodableid=null ::> 
 TagManager.hx 112 getTaxoBySpodID
INFO - 2012-09-24 14:07:55 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:07:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:07:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:07:55 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:07:55 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:07:55 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:07:55 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:07:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:07:55 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:08:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:00 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:14:01 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:14:02 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:14:02 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:14:02 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:03 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:14:03 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:14:03 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:14:03 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:14:03 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:14:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:14:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:14:19 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:14:19 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:14:19 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:14:41 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:14:41 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:14:45 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:14:45 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:14:45 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:14:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:14:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:14:45 --> getSpoTablenews ::> 
 TagManager.hx 289 getSpodTable
INFO - 2012-09-24 14:14:45 --> spodablevo.News ::> 
 TagManager.hx 294 getSpodTable
INFO - 2012-09-24 14:14:45 --> managersys.db.Manager ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:15:14 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:15:14 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:15:19 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:15:19 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:15:19 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:15:19 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:15:19 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:15:19 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:15:19 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:15:19 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:15:19 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:23 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:16:23 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:16:24 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:16:24 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:16:24 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:25 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:25 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:25 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:25 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:25 --> spodableid=7 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:25 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:25 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:25 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:25 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:25 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:25 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:25 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:28 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:29 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:29 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:29 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:29 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:29 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:29 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:29 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:29 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:29 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:29 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:29 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:29 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:29 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:29 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:29 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:29 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:31 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:31 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:31 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:31 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:31 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:31 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:31 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:31 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:31 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:31 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:31 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:31 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:31 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:31 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:42 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:16:42 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:16:45 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:16:45 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:16:45 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:46 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:46 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:46 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:46 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:46 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:46 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:46 --> spodableid=7 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:46 --> istraductable6 ::> 
 TagManager.hx 120 getTaxoBySpodID
INFO - 2012-09-24 14:16:46 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:46 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:46 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:46 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:46 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:46 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:46 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:46 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:46 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:49 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:49 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:49 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:49 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:49 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:49 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:49 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:49 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:49 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:49 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:49 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:16:52 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:52 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:52 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:52 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:52 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:52 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:16:52 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:16:52 --> istraductable5 ::> 
 TagManager.hx 120 getTaxoBySpodID
INFO - 2012-09-24 14:16:52 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:16:52 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:16:52 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:16:52 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:16:52 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:16:52 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:16:52 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:16:52 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:16:52 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:00 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:00 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:00 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:00 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:20:00 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:20:00 --> istraductable5 ::> 
 TagManager.hx 120 getTaxoBySpodID
INFO - 2012-09-24 14:20:00 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:00 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:00 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:00 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:00 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:20:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:20:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:16 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:16 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:16 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:16 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:16 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:16 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:20:16 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:20:16 --> istraductable5 ::> 
 TagManager.hx 120 getTaxoBySpodID
INFO - 2012-09-24 14:20:16 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:17 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:17 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:17 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:17 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:20:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:20:17 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:21 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:20:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:22 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:22 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:22 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:22 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:20:22 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:20:22 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:20:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:20:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:20:22 --> getSpoTablenews ::> 
 TagManager.hx 290 getSpodTable
INFO - 2012-09-24 14:20:22 --> spodablevo.News ::> 
 TagManager.hx 295 getSpodTable
INFO - 2012-09-24 14:20:22 --> managersys.db.Manager ::> 
 TagManager.hx 297 getSpodTable
INFO - 2012-09-24 14:20:22 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:20:22 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:20:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:14 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:23:14 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:23:17 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:23:17 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:23:17 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:18 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:18 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:18 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:18 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:18 --> spodableid=7 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:18 --> istraductable6 ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:23:18 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:18 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:18 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:18 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:18 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:20 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:20 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:20 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:20 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:20 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:20 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:20 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:20 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:20 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:20 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:20 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:20 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:20 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:20 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:20 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:20 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:20 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:23 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:24 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:24 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:24 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:24 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:24 --> istraductable5 ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:23:24 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:24 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:24 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:24 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:24 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:25 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:26 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:26 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:26 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:26 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:26 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:26 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:26 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:26 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:26 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:26 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:26 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:26 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:26 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:26 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:26 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:26 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:37 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:37 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:37 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:37 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:37 --> spodableid=5 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:38 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:38 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:38 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:38 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:38 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:38 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:38 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:38 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:23:52 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:52 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:52 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:52 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:52 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:52 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:23:52 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:23:52 --> istraductable5 ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:23:52 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:23:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:23:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:23:53 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:23:53 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:23:53 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:23:53 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:23:53 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:23:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:24:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:24:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:24:22 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:24:22 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:24:22 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:24:22 --> spodableid=vo.News ::> 
 TagManager.hx 111 getTaxoBySpodID
INFO - 2012-09-24 14:24:22 --> spodableid=6 ::> 
 TagManager.hx 113 getTaxoBySpodID
INFO - 2012-09-24 14:24:22 --> istraductable5 ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:24:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:24:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:24:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:24:22 --> getSpoTablenews ::> 
 TagManager.hx 291 getSpodTable
INFO - 2012-09-24 14:24:22 --> spodablevo.News ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-24 14:24:22 --> managersys.db.Manager ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:24:22 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:24:22 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:24:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:43 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-24 14:32:44 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-24 14:32:47 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-24 14:32:47 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:32:47 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:47 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:47 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:47 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:47 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:47 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:47 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:32:47 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:47 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:47 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:47 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:47 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:47 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:47 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:32:47 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:32:47 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:49 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:49 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:50 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:50 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:50 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:50 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:50 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:50 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:32:50 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:50 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:50 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:50 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:50 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:50 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:50 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:32:50 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:32:50 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:32:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:53 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:53 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:53 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:53 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:32:53 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:32:54 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:32:54 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:32:54 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:32:54 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:32:54 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:32:54 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:32:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:32:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:06 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:06 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:06 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:06 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:06 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:06 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:33:06 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:07 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:07 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:07 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:07 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:07 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:07 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:33:07 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:33:07 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:09 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:09 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:10 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:10 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:10 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:10 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:33:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:10 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:10 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:10 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:10 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:33:10 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:33:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:14 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:14 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:14 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:14 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:14 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:14 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:33:14 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:15 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:15 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:15 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:15 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:33:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:33:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:20 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:20 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:20 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:20 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:20 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:20 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:33:20 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:21 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:21 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:21 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:21 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:21 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:21 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:33:21 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:33:21 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:23 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-24 14:33:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:23 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:23 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:23 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:23 --> spodableid=vo.News ::> 
 TagManager.hx 121 getTaxoBySpodID
INFO - 2012-09-24 14:33:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-24 14:33:23 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-24 14:33:23 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-24 14:33:23 --> getSpoTablenews ::> 
 TagManager.hx 293 getSpodTable
INFO - 2012-09-24 14:33:23 --> spodablevo.News ::> 
 TagManager.hx 298 getSpodTable
INFO - 2012-09-24 14:33:23 --> managersys.db.Manager ::> 
 TagManager.hx 300 getSpodTable
INFO - 2012-09-24 14:33:23 --> spodTAble=actu ::> 
 TagManager.hx 90 getTaxos
INFO - 2012-09-24 14:33:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 98 getTaxos
INFO - 2012-09-24 14:33:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
