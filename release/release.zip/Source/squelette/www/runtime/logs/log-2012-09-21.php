<?php exit; ?>

INFO - 2012-09-21 14:06:47 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-09-21 14:06:48 --> pas identifié ::> 
 AuthRequestDecorator.hx 39 handleRequest
INFO - 2012-09-21 14:06:58 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-09-21 14:06:58 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> 
 FormElement.hx 129 populate
INFO - 2012-09-21 14:06:58 --> result.next={
	id : 1, 
	mdp : admin, 
	nom : admin
} ::> 
 Login.hx 128 success
INFO - 2012-09-21 14:07:00 --> index ::> 
 Pipo.hx 135 index
INFO - 2012-09-21 14:07:00 --> after ::> 
 Pipo.hx 141 index
INFO - 2012-09-21 14:07:01 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 14:07:01 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:01 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-19 07:50:18
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : bureau_fmt4.jpeg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:14 --> voName=Edito ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 14:07:14 --> choix id=null vo=Edito ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:14 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 14:07:14 --> Editoit s a formElement >{
	classe : microbe.form.elements.AjaxArea, 
	type : formElement, 
	champs : rhoooooo
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:16 --> voName=RelationTest ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 14:07:16 --> choix id=null vo=RelationTest ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 RelationTest.hx 44 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> make ::> 
 ChildTest.hx 45 make
INFO - 2012-09-21 14:07:16 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 14:07:16 --> RelationTestit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : unAutren
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:16 --> sousvoName=ChildTest ::> 
 CollectionBehaviour.hx 39 create
INFO - 2012-09-21 14:07:16 --> ChildTestit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:16 --> ChildTestit s a formElement >{
	classe : microbe.form.elements.ImageUploader, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:16 --> ChildTestit s a formElement >{
	classe : microbe.form.elements.Mock, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:16 --> before collectionWrapper ::> 
 CollectionBehaviour.hx 65 create
INFO - 2012-09-21 14:07:16 --> new Collection WrapperChildTest ::> 
 CollectionWrapper.hx 13 new
INFO - 2012-09-21 14:07:16 --> after new Collection WrapperChildTest ::> 
 CollectionWrapper.hx 18 new
INFO - 2012-09-21 14:07:16 --> y'a de la data30voNameRelationTest ::> 
 CollectionBehaviour.hx 75 create
INFO - 2012-09-21 14:07:16 --> addElementmicrobe.form.elements.CollectionElement ::> 
 CollectionWrapper.hx 35 addElement
INFO - 2012-09-21 14:07:16 --> addElementmicrobe.form.elements.CollectionElement ::> 
 CollectionWrapper.hx 35 addElement
INFO - 2012-09-21 14:07:16 --> addElementmicrobe.form.elements.CollectionElement ::> 
 CollectionWrapper.hx 35 addElement
INFO - 2012-09-21 14:07:24 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 14:07:24 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:24 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-19 07:50:18
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : bureau_fmt4.jpeg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> choix id=23 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-18 15:03:10
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> choix id=7 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-06-29 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : affames-01-6.jpg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : true
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> choix id=22 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-18 15:02:31
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : MOV19-teeshirt-cinema-bob-l-eponge-face-1227107766-zoom.jpg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:07:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:45 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 14:08:45 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:08:46 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-19 07:50:18
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : bureau_fmt4.jpeg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:46 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> choix id=23 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-18 15:03:10
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> choix id=22 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-18 15:02:31
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : MOV19-teeshirt-cinema-bob-l-eponge-face-1227107766-zoom.jpg
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 14:08:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:16 --> index ::> 
 Pipo.hx 135 index
INFO - 2012-09-21 15:13:16 --> after ::> 
 Pipo.hx 141 index
INFO - 2012-09-21 15:13:25 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:13:25 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:13:25 --> null ::> 
 Api.hx 219 getLast
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> ajoute ::> 
 Pipo.hx 200 ajoute
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:29 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:41 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=false  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-12-11</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:<p>ben oui</p></p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-21 15:13:41 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-21 15:13:41 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-21 15:13:41 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviourtitre--pim ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviourdate--2012-12-11 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviourcontenu--<p>ben oui</p> ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:41 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:13:41 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:13:42 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:13:42 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:13:42 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pim
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>ben oui</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> choix id=1 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pim
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>ben oui</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:13:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:13 --> index ::> 
 Pipo.hx 135 index
INFO - 2012-09-21 15:14:13 --> after ::> 
 Pipo.hx 141 index
INFO - 2012-09-21 15:14:16 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:14:16 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:14:16 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pim
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>ben oui</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:14:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:14:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:14:17 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:14:17 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:14:17 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:14:17 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:14:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:14:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:14:17 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:14:17 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:14:17 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:14:17 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:14:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:14:17 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:14:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:14:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:14:32 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:14:32 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:14:32 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:14:32 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:14:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:14:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:14:32 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:14:32 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:14:32 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:14:32 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:14:32 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:14:32 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:27:51 --> index ::> 
 Pipo.hx 135 index
INFO - 2012-09-21 15:27:51 --> after ::> 
 Pipo.hx 141 index
INFO - 2012-09-21 15:27:54 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:27:54 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:27:54 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pim
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>ben oui</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:54 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:27:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:27:55 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:27:55 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:27:55 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:27:55 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:27:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:27:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:27:55 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:27:55 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:27:55 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:27:55 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:27:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:27:55 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:27:58 --> ajoute ::> 
 Pipo.hx 200 ajoute
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:27:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> map=<div class='indent2'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:test</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-12-11</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:hello la compagnie</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-21 15:28:02 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-21 15:28:02 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-21 15:28:02 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviourtitre--test ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviourdate--2012-12-11 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviourdatelitterale-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviourcontenu--hello la compagnie ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-21 15:28:02 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-21 15:28:02 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:28:02 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:28:02 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:28:02 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:02 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:02 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:02 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:02 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:02 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:28:03 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:03 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:03 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:03 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:03 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:03 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:28:03 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:28:03 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:28:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:17 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:17 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:17 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:17 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:28:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:17 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:17 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:17 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:17 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:28:17 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:28:17 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:28:30 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:30 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:30 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:30 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:30 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:30 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:28:31 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:28:31 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:28:31 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:28:31 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:28:31 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:28:31 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:28:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:28:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:47:04 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-21 15:47:04 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-21 15:47:06 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:47:06 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:47:06 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:07 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:47:07 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:47:07 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:47:07 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:47:07 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:47:07 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:47:07 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:47:07 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:47:07 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:47:07 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:47:07 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:47:07 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:47:07 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:47:07 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:47:57 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:47:57 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:47:57 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:47:59 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:47:59 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:47:59 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:47:59 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:47:59 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:47:59 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:47:59 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:47:59 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:47:59 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:47:59 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:47:59 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:47:59 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:47:59 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:47:59 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:52:49 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-21 15:52:49 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-21 15:52:51 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:52:51 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:52:51 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:52:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:52:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:52:51 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:52:51 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:52:51 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:52:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:52:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:52:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:52:51 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:52:51 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:52:51 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:52:51 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:52:51 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:52:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:53:00 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:53:00 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:53:00 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:53:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:53:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:53:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:53:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:53:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:53:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:53:00 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:53:00 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:53:00 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:53:00 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:53:00 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:53:00 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:53:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:53:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:57:42 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-21 15:57:43 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-21 15:57:45 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:57:45 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:57:45 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:57:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:57:45 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:57:45 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:57:45 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:57:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:57:45 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:57:45 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:57:45 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:57:45 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:57:45 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:57:45 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:57:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:57:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:57:47 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:34 --> index ::> 
 Pipo.hx 156 index
INFO - 2012-09-21 15:58:34 --> after ::> 
 Pipo.hx 162 index
INFO - 2012-09-21 15:58:37 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-21 15:58:37 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:58:37 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:58:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:58:37 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:58:37 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:58:37 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:58:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:58:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:58:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:58:37 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:58:37 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:58:37 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:58:37 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:58:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:58:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:40 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> choix id=2 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : test
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-21 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : hello la compagnie
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:58:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:58:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:58:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:58:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:58:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:58:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-21 15:58:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-21 15:58:49 --> getSpoTablenews ::> 
 TagManager.hx 272 getSpodTable
INFO - 2012-09-21 15:58:49 --> spodablevo.News ::> 
 TagManager.hx 277 getSpodTable
INFO - 2012-09-21 15:58:49 --> managersys.db.Manager ::> 
 TagManager.hx 279 getSpodTable
INFO - 2012-09-21 15:58:49 --> spodTAble=actu ::> 
 TagManager.hx 88 getTaxos
INFO - 2012-09-21 15:58:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 96 getTaxos
INFO - 2012-09-21 15:58:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-21 15:58:51 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
