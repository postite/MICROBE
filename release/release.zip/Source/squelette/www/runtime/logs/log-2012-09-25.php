<?php exit; ?>

INFO - 2012-09-25 08:34:51 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-25 08:34:51 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-25 08:34:53 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-25 08:34:53 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:34:53 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:53 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:34:53 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:34:53 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:34:53 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:34:53 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:34:53 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:34:53 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:34:54 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:34:54 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:34:54 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:34:54 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:34:54 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:34:54 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:34:54 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:34:54 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:34:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:22 --> index ::> 
 Pipo.hx 157 index
INFO - 2012-09-25 08:35:22 --> after ::> 
 Pipo.hx 163 index
INFO - 2012-09-25 08:35:24 --> voName=News ::> 
 Pipo.hx 89 nav
INFO - 2012-09-25 08:35:24 --> choix id=null vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:35:24 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:24 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:24 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:24 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:24 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:35:24 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:24 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:24 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:24 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:24 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:35:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:35:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> choix id=7 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:28 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:29 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:29 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:29 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:29 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:29 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:29 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:35:29 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:29 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:29 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:29 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:29 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:29 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:29 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:35:29 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:35:29 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:35 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:35 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:35 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:35 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:35 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:35:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:35 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:35 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:35 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:35 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:35:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:35:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:35:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:37 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:37 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:37 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:37 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:35:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:35:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:35:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:35:37 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:35:37 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:35:37 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:35:37 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:35:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:35:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:10 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:10 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:10 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:10 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:10 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:36:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:10 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:10 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:10 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:10 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:10 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:10 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:36:10 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:36:10 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:14 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:14 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:14 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:14 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:14 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:14 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:36:14 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:14 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:14 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:14 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:14 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:14 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:14 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:36:14 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:36:14 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:18 --> choix id=5 vo=News ::> 
 Pipo.hx 104 choix
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:18 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:18 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:18 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:18 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:36:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:18 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:18 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:18 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:18 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:36:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:36:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:36:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:25 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:25 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:25 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:25 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:36:25 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:36:25 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:36:25 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:36:25 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:36:25 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:36:25 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:36:25 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:36:25 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:36:25 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:41:46 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 08:41:46 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 08:41:48 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:41:48 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:41:48 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:41:48 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:41:48 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:41:48 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:41:48 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:41:48 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:41:48 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:41:48 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:41:49 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:41:49 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:41:49 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:41:49 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:41:49 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:41:49 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:41:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:41:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:53 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 08:42:53 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 08:42:54 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:42:55 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:42:55 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : popop
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:55 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:55 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:55 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:55 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:42:55 --> microbe.TagManager.getTags{microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:55 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:55 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:55 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:55 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:55 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:55 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:42:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:42:55 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:57 --> choix id=5 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:58 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:58 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:58 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:58 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:58 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:58 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:42:58 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:58 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:58 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:58 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:58 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:58 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:58 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:42:58 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:42:58 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : english
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:42:59 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:59 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:59 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:59 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:59 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:59 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:42:59 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:42:59 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:42:59 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:42:59 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:42:59 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:42:59 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:42:59 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:42:59 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:42:59 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:43:02 --> choix id=5 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : franche
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-24 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:02 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:43:02 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:43:02 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:43:02 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:43:02 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:43:02 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:43:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:43:02 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:43:02 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:43:02 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:43:02 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:43:02 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:43:02 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:43:02 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:43:02 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:43:03 --> ajoute ::> 
 Pipo.hx 264 ajoute
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:43:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:local</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-25</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:maintenant</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:<p>y'a de la joie&#160;</p></p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-25 08:44:23 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-25 08:44:23 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-25 08:44:23 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviourtitre--local ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviourdate--2012-09-25 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviourdatelitterale--maintenant ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviourcontenu--<p>y'a de la joie&#160;</p> ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:44:23 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:44:23 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:44:23 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:44:23 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:44:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:44:24 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:44:24 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:44:24 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:44:24 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:44:24 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:44:24 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:44:24 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:44:24 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:44:24 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:44:24 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:44:24 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:44:24 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:44:24 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:44:27 --> choix id=8 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:28 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:44:28 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:44:28 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:44:28 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:44:28 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:44:28 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:44:28 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:44:28 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:44:28 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:44:28 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:44:28 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:44:28 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:44:28 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:44:28 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:44:28 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:44:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:55 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 08:47:55 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 08:47:56 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:47:56 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:47:56 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:56 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:47:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:47:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:47:57 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:47:57 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:47:57 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:47:57 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:47:57 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:47:57 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:47:57 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:47:57 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:47:57 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:47:57 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:47:57 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:47:57 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:47:57 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:13 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 08:49:13 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 08:49:15 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:49:15 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:49:15 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:15 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:15 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:15 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:15 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:49:15 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:15 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:15 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:15 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:15 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:15 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:15 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:49:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:49:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:17 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:17 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:17 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:17 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:18 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:18 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:49:18 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:18 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:18 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:18 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:18 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:18 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:18 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:49:18 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:49:18 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:31 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:8ElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:local_en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-25</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:maintenant</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:<p>y'a de la joie&#160;</p></p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:8</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-25 08:49:31 --> record8 ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-25 08:49:31 --> map.id!=null ::> 
 Api.hx 319 recClassMap
INFO - 2012-09-25 08:49:31 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-25 08:49:31 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviourtitre--local_en ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviourdate--2012-09-25 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviourdatelitterale--maintenant ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviourcontenu--<p>y'a de la joie&#160;</p> ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:49:31 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:49:31 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:49:31 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:49:31 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:32 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:32 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:32 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:32 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:49:32 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:32 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:32 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:32 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:32 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:49:32 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:49:32 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:35 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:35 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:35 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:35 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:49:35 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:35 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:35 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:35 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:35 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:35 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:35 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:49:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:49:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:36 --> choix id=8 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:49:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:37 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:37 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:37 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:37 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:49:37 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:49:37 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:49:37 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:49:37 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:49:37 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:49:37 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:49:37 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:49:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:49:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:51:55 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 08:51:56 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 08:51:58 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:51:58 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:51:58 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:51:58 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:51:58 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:51:58 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:51:58 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:51:58 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:51:58 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:51:58 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:51:58 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:51:58 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:51:58 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:51:58 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:51:58 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:51:58 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:51:58 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:51:58 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:00 --> choix id=8 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:01 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:01 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:01 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:01 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:01 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:01 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:52:01 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:01 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:01 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:01 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:01 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:01 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:01 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:52:01 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:52:01 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:local_en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-25</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:maintenant</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:<p>y'a de la joie&#160;</p></p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:8</p></div>}</p></div></div> ::> 
 Api.hx 187 getClassMap
INFO - 2012-09-25 08:52:07 --> recordnull ::> 
 Api.hx 316 recClassMap
INFO - 2012-09-25 08:52:07 --> after ::> 
 Api.hx 326 recClassMap
INFO - 2012-09-25 08:52:07 --> record ::> 
 MicroCreator.hx 62 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviourtitre--local_en ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviourdate--2012-09-25 ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviourdatelitterale--maintenant ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviourcontenu--<p>y'a de la joie&#160;</p> ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviourimage-- ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> formElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> FormElementBehaviouren_ligne--false ::> 
 FormElementBehaviour.hx 36 record
INFO - 2012-09-25 08:52:07 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> dataElement ::> 
 MicroCreator.hx 64 record
INFO - 2012-09-25 08:52:07 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 08:52:07 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:52:07 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:07 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:08 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:08 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:08 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:08 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:08 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:08 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:52:08 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:08 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:08 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:08 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:08 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:08 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:08 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:52:08 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:52:08 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:11 --> choix id=8 vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:11 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:11 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:11 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:11 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:11 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:11 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:52:11 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:11 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:11 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:11 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:11 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:11 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:11 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:52:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:52:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 08:52:13 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:13 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:13 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:13 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:13 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:13 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 08:52:13 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 08:52:13 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 08:52:13 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 08:52:13 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 08:52:13 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 08:52:13 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 08:52:13 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 08:52:13 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 08:52:13 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:45:29 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:45:29 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 11:45:31 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:45:31 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:45:31 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:45:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:45:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:45:32 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:45:32 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:45:32 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:45:32 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:45:32 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:45:32 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:45:32 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:45:32 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:45:32 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:45:32 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:45:32 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:45:32 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:45:32 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:46:41 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:46:41 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 11:46:42 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:46:42 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:46:42 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:42 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:46:43 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:46:43 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:46:43 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:46:43 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:46:43 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:46:43 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:46:43 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:46:43 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:46:43 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:46:43 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:46:43 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:46:43 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:46:43 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:46:43 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:46:43 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:46:51 --> bytes=169029
INFO - 2012-09-25 11:47:32 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:47:32 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 11:47:33 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:47:33 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:47:33 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:47:34 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:47:34 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:47:34 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:47:34 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:47:34 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:47:34 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:47:34 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:47:34 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:47:34 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:47:34 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:47:34 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:47:34 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:47:34 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:47:34 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:47:34 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:47:41 --> bytes=169029
INFO - 2012-09-25 11:48:50 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:48:50 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:48:50 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:50 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:48:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:48:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:48:51 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:48:51 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:48:51 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:48:51 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:48:51 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:48:51 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:48:51 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:48:51 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:48:51 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:48:51 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:48:51 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:48:51 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:48:51 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:49:07 --> bytes=1305016
INFO - 2012-09-25 11:49:25 --> bytes=169029
INFO - 2012-09-25 11:50:20 --> bytes=169029
INFO - 2012-09-25 11:51:21 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:51:21 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:51:21 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:21 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:51:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:51:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:51:22 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:51:22 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:51:22 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:51:22 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:51:22 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:51:22 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:51:22 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:51:22 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:51:22 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:51:22 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:51:22 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:51:22 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:51:22 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:51:28 --> bytes=169029
INFO - 2012-09-25 11:53:14 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:53:14 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 11:53:16 --> voName=News ::> 
 Pipo.hx 90 nav
INFO - 2012-09-25 11:53:16 --> choix id=null vo=News ::> 
 Pipo.hx 105 choix
INFO - 2012-09-25 11:53:16 --> micrabeLast ::> 
 Api.hx 216 getLast
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> 
 FormElementBehaviour.hx 23 create
INFO - 2012-09-25 11:53:16 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:53:16 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:53:16 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:53:16 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:53:16 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:53:16 --> spodableid=vo.News ::> 
 TagManager.hx 124 getTaxoBySpodID
INFO - 2012-09-25 11:53:16 --> microbe.TagManager.getTags{} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:53:16 --> spod ::> 
 Api.hx 149 tags
INFO - 2012-09-25 11:53:16 --> spodnews ::> 
 Api.hx 154 tags
INFO - 2012-09-25 11:53:16 --> getSpoTablenews ::> 
 TagManager.hx 296 getSpodTable
INFO - 2012-09-25 11:53:16 --> spodablevo.News ::> 
 TagManager.hx 301 getSpodTable
INFO - 2012-09-25 11:53:16 --> managersys.db.Manager ::> 
 TagManager.hx 303 getSpodTable
INFO - 2012-09-25 11:53:16 --> spodTAble=actu ::> 
 TagManager.hx 91 getTaxos
INFO - 2012-09-25 11:53:16 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> 
 TagManager.hx 99 getTaxos
INFO - 2012-09-25 11:53:16 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> 
 Api.hx 159 tags
INFO - 2012-09-25 11:53:24 --> bytes=169029
INFO - 2012-09-25 11:57:57 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:57:57 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 11:59:35 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 11:59:35 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 12:11:38 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 12:11:38 --> after ::> 
 Pipo.hx 164 index
INFO - 2012-09-25 12:21:15 --> index ::> 
 Pipo.hx 158 index
INFO - 2012-09-25 12:21:15 --> after ::> 
 Pipo.hx 164 index
