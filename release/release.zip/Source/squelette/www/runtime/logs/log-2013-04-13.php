<?php exit; ?>

INFO - 2013-04-13 10:52:28 --> pas identifié ::> AuthRequestDecorator.hx 39 handleRequest
INFO - 2013-04-13 10:53:32 --> pas identifié ::> AuthRequestDecorator.hx 39 handleRequest
INFO - 2013-04-13 10:53:38 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> FormElement.hx 129 populate
INFO - 2013-04-13 10:53:38 --> v={logForm_login => admin, logForm_mdp => admin, logForm_submit => soumettre, logForm_formSubmitted => true} ::> FormElement.hx 129 populate
INFO - 2013-04-13 10:53:39 --> result.next={
	id : 1, 
	mdp : admin, 
	nom : admin
} ::> Login.hx 127 success
INFO - 2013-04-13 10:53:41 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 10:53:41 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 10:53:43 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:53:43 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:53:43 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:44 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:53:44 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:53:44 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:53:44 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:53:44 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:53:44 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:53:44 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:53:44 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:53:44 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:53:44 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:53:44 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:53:44 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:53:44 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:53:44 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:53:44 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:53:44 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:53:44 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:53:48 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:53:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:54:01 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pogo</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:54:01 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:55:08 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 10:55:08 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 10:55:10 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:55:10 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:55:10 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:10 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:55:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:55:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:55:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:55:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:55:11 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:55:11 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:55:11 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:55:11 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:55:11 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:55:11 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:55:11 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:55:11 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:55:11 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:55:11 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:55:11 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:55:11 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:55:13 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:13 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:19 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:tak</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:55:19 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:55:26 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:26 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:55:32 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:yhu</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:55:32 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:56:32 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 10:56:33 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 10:56:35 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:56:35 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:56:35 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:36 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:56:36 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:56:36 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:56:36 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:56:36 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:56:36 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:56:36 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:56:36 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:56:36 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:56:36 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:56:36 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:56:36 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:56:36 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:56:36 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:56:36 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:56:36 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:56:36 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:56:39 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:39 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:polki</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:56:48 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:56:48 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:56:48 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:56:48 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2012-09-25 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:48 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:56:49 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:56:49 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:56:49 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:56:49 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:56:49 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:56:49 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:56:49 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:56:49 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:56:49 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:56:49 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:56:49 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:56:49 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:56:49 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:56:49 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:56:49 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:56:49 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:56:49 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:57:15 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:9ElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:local_en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2012-09-25</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:maintenant</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:<p>y'a de la joie&#160;</p></p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:en</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:8</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:57:15 --> record9 ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:57:15 --> map.id!=null ::> Api.hx 336 recClassMap
INFO - 2013-04-13 10:57:15 --> after ::> Api.hx 350 recClassMap
INFO - 2013-04-13 10:57:15 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviourtitre--local_en ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviourdate--2012-09-25 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviourdatelitterale--maintenant ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviourcontenu--<p>y'a de la joie&#160;</p> ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 10:57:15 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 10:57:15 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:57:15 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:57:15 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:15 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:57:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:57:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:57:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:57:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:57:16 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:57:16 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:57:16 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:57:16 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:57:16 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:57:16 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:57:16 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:57:16 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:57:16 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:57:16 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:57:16 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:57:16 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:57:27 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:35 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:lupin</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:57:35 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 10:57:36 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:57:36 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:57:36 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:57:36 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:57:36 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:57:36 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:57:36 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:57:36 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:57:36 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:57:36 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:57:36 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:57:36 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:57:36 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:57:36 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:57:36 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:57:36 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:57:36 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:57:37 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:57:37 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:57:37 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:59:25 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 10:59:25 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 10:59:27 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 10:59:27 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 10:59:27 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:27 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:59:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:59:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:59:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:59:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:59:28 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 10:59:28 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 10:59:28 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 10:59:28 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 10:59:28 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 10:59:28 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 10:59:28 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 10:59:28 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 10:59:28 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 10:59:28 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 10:59:28 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 10:59:28 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 10:59:31 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:31 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 10:59:39 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:fugees</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 10:59:39 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:00:56 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:00:56 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:00:59 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:00:59 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:00:59 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : local_en
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : maintenant
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : <p>y'a de la joie&#160;</p>
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:00:59 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:00 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:01:00 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:01:00 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:01:00 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:01:00 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:01:00 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:01:00 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:01:00 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:01:00 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:01:00 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:01:00 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:01:00 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:01:00 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:01:00 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:01:00 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:01:00 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:01:00 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:01:02 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:02 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:01:13 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pokilght</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:01:13 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:01:13 --> after ::> Api.hx 350 recClassMap
INFO - 2013-04-13 11:01:13 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviourtitre--pokilght ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:01:13 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:01:13 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:28 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:05:28 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:05:30 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:05:30 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:05:30 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pokilght
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:05:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:05:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:05:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:05:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:05:31 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:05:31 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:05:31 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:05:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:05:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:05:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:05:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:05:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:05:31 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:05:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:05:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:05:31 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:05:34 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:34 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:tele</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:05:41 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:05:41 --> after ::> Api.hx 353 recClassMap
INFO - 2013-04-13 11:05:41 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviourtitre--tele ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:05:41 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:05:41 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:05:41 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:05:41 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : tele
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:05:42 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:05:43 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:05:43 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:05:43 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:05:43 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:05:43 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:05:43 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:05:43 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:05:43 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:05:43 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:05:43 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:05:43 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:05:43 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:05:43 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:05:43 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:05:43 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:05:43 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:20 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:06:20 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:06:22 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:06:22 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:06:22 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : tele
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:23 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:06:23 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:23 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:23 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:06:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:06:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:23 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:25 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:bnuyh</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:06:33 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:06:33 --> after ::> Api.hx 354 recClassMap
INFO - 2013-04-13 11:06:33 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviourtitre--bnuyh ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:33 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:33 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:06:33 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:06:33 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bnuyh
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:33 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:34 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:06:34 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:34 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:34 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:34 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:34 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:34 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:34 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:34 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:06:35 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:06:35 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:35 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:45 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:12ElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:bnuyh</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:06:45 --> record12 ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:06:45 --> map.id!=null ::> Api.hx 336 recClassMap
INFO - 2013-04-13 11:06:45 --> after ::> Api.hx 354 recClassMap
INFO - 2013-04-13 11:06:45 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviourtitre--bnuyh ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:06:45 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:06:45 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:06:45 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:06:45 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bnuyh
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:06:46 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:46 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:46 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:46 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:46 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:46 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:06:46 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:46 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:06:46 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:06:46 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:06:46 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:06:46 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:06:46 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:06:46 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:06:46 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:06:46 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:06:46 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:07:20 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:07:20 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:07:22 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:07:22 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:07:22 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bnuyh
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:07:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:07:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:07:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:07:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:07:23 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:07:23 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:07:23 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:07:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:07:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:07:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:07:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:07:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:07:23 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:07:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:07:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:07:23 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:07:25 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:25 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:jh</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:07:32 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:07:32 --> after ::> Api.hx 355 recClassMap
INFO - 2013-04-13 11:07:32 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviourtitre--jh ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:07:32 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:07:32 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:07:32 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:07:32 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : jh
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:07:33 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:07:33 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:07:33 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:07:33 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:07:33 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:07:33 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:07:33 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:07:33 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:07:33 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:07:33 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:07:33 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:07:33 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:07:33 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:07:33 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:07:33 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:07:33 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:07:33 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:09:28 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:09:28 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:09:30 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:09:30 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:09:30 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : jh
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:30 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:09:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:09:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:09:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:09:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:09:31 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:09:31 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:09:31 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:09:31 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:09:31 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:09:31 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:09:31 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:09:31 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:09:31 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:09:31 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:09:31 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:09:31 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:09:35 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:35 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:hjuy</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:09:44 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:09:44 --> after ::> Api.hx 355 recClassMap
INFO - 2013-04-13 11:09:44 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviourtitre--hjuy ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:44 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:44 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:09:44 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:09:44 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : hjuy
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:44 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:45 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:09:45 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:09:45 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:09:45 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:09:45 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:09:45 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:09:45 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:09:45 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:09:45 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:09:45 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:09:45 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:09:45 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:09:45 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:09:45 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:09:45 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:09:45 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:09:45 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:09:53 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:53 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:09:59 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pim</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:09:59 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:09:59 --> after ::> Api.hx 355 recClassMap
INFO - 2013-04-13 11:09:59 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviourtitre--pim ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:09:59 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:09:59 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:10:43 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:10:43 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:10:45 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:10:45 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:10:45 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:45 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:46 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:10:46 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:10:46 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:10:46 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:10:46 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:10:46 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:10:46 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:10:46 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:10:46 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:10:46 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:10:46 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:10:46 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:10:46 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:10:46 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:10:46 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:10:46 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:10:46 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:10:52 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:10:52 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:11:01 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:nuji</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:11:01 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:12:58 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:12:58 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:13:00 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:13:00 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:13:00 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:00 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:01 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:13:01 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:13:01 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:13:01 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:13:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:13:01 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:13:01 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:13:01 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:13:01 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:13:01 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:13:01 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:13:01 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:13:01 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:13:01 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:13:01 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:13:01 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:13:01 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:13:03 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:03 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:13:17 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:court</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:13:17 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:16:54 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:16:54 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:17:14 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:17:14 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:17:14 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:15 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:17:15 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:17:15 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:17:15 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:17:15 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:17:15 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:17:15 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:17:15 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:17:15 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:17:15 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:17:15 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:17:15 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:17:15 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:17:15 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:17:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:17:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:17:15 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:17:23 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:23 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:17:32 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:telecommande</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:17:32 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:17:32 --> DBINFOS{
	name : actu, 
	indexes : [], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-13 11:19:02 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:19:02 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:19:06 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:19:06 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:19:06 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 1970-01-01 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:06 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:08 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:19:08 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:19:08 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:19:08 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:19:08 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:19:08 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:19:08 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:19:08 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:19:08 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:19:08 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:19:08 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:19:08 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:19:08 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:19:08 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:19:08 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:19:08 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:19:08 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:19:31 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:15ElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:bullo</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:1970-01-01</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:19:31 --> record15 ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:19:31 --> map.id!=null ::> Api.hx 336 recClassMap
INFO - 2013-04-13 11:19:31 --> after ::> Api.hx 356 recClassMap
INFO - 2013-04-13 11:19:31 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviourtitre--bullo ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviourdate--1970-01-01 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:19:31 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:19:31 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:19:31 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:19:32 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bullo
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:32 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:19:32 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:19:32 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:19:32 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:19:32 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:19:32 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:19:32 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:19:32 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:19:32 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:19:32 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:19:32 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:19:32 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:19:32 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:19:32 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:19:32 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:19:32 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:19:32 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:19:43 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:43 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:19:53 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:hybnyfd</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:19:53 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:19:53 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-13 11:25:20 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:25:20 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:25:22 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:25:22 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:25:22 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : bullo
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:22 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:25:22 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:25:22 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:25:22 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:25:22 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:25:22 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:25:22 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:25:22 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:25:23 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:25:23 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:25:23 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:25:23 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:25:23 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:25:23 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:25:23 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:25:23 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:25:23 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:25:24 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:24 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:gerande sie</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:25:41 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:25:41 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-13 11:25:41 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-13 11:25:41 --> after ::> Api.hx 357 recClassMap
INFO - 2013-04-13 11:25:41 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviourtitre--gerande sie ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:25:41 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:25:41 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:25:41 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:25:41 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : gerande sie
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:41 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:25:42 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:25:42 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:25:42 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:25:42 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:25:42 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:25:42 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:25:42 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:25:42 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:25:42 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:25:42 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:25:42 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:25:42 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:25:42 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:25:42 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:25:42 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:25:42 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:25:42 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:30:52 --> index ::> Pipo.hx 171 index
INFO - 2013-04-13 11:30:53 --> after ::> Pipo.hx 179 index
INFO - 2013-04-13 11:30:55 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:30:55 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:30:55 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : gerande sie
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:55 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:30:55 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:30:55 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:30:55 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:30:55 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:30:55 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:30:55 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:30:55 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:30:55 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:30:55 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:30:55 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:30:55 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:30:55 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:30:55 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:30:55 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:30:55 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:30:55 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:30:57 --> ajoute ::> Pipo.hx 283 ajoute
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:30:57 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : null
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> map=<div class='indent3'><div class='microtrace'><p>MICROFIELDLIST: News</p><p>-, TYPE:spodable TAGGABLE=true  POS:null, FIELD:  ID:nullElementId:, VALUE:</p><p>{<div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:titre,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_titre<br/>value:pokilolnnn</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:date,<br/>voName:News,<br/>element:microbe.form.elements.AjaxDate, <br/>elementId:News_date<br/>value:2013-04-13</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:datelitterale,<br/>voName:News,<br/>element:microbe.form.elements.AjaxInput, <br/>elementId:News_datelitterale<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:contenu,<br/>voName:News,<br/>element:microbe.form.elements.AjaxEditor, <br/>elementId:News_contenu<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:image,<br/>voName:News,<br/>element:microbe.form.elements.ImageUploader, <br/>elementId:News_image<br/>value:</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:formElement<br/>field:en_ligne,<br/>voName:News,<br/>element:microbe.form.elements.CheckBox, <br/>elementId:News_en_ligne<br/>value:false</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:lang,<br/>voName:News,<br/>element:, <br/>elementId:News_lang<br/>value:fr</p></div>, <div class='microfieldTrace'><p>MICROFIELD :<br/>type:dataElement<br/>field:id_ref,<br/>voName:News,<br/>element:, <br/>elementId:News_id_ref<br/>value:</p></div>}</p></div></div> ::> Api.hx 191 getClassMap
INFO - 2013-04-13 11:31:08 --> recordnull ::> Api.hx 333 recClassMap
INFO - 2013-04-13 11:31:08 --> DBINFOS{
	name : actu, 
	indexes : [{
	keys : [titre], 
	unique : true
}], 
	relations : [], 
	hfields : {contenu => {
	name : contenu, 
	isNull : false, 
	t : DText
}, titre => {
	name : titre, 
	isNull : false, 
	t : DString(255)
}, datelitterale => {
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
}, en_ligne => {
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
}, poz => {
	name : poz, 
	isNull : false, 
	t : DInt
}, date => {
	name : date, 
	isNull : false, 
	t : DDate
}, id_ref => {
	name : id_ref, 
	isNull : false, 
	t : DInt
}, image => {
	name : image, 
	isNull : false, 
	t : DString(255)
}, lang => {
	name : lang, 
	isNull : false, 
	t : DString(11)
}, id => {
	name : id, 
	isNull : false, 
	t : DId
}}, 
	key : [id], 
	fields : [{
	name : poz, 
	isNull : false, 
	t : DInt
},{
	name : id, 
	isNull : false, 
	t : DId
},{
	name : titre, 
	isNull : false, 
	t : DString(255)
},{
	name : date, 
	isNull : false, 
	t : DDate
},{
	name : contenu, 
	isNull : false, 
	t : DText
},{
	name : image, 
	isNull : false, 
	t : DString(255)
},{
	name : datelitterale, 
	isNull : false, 
	t : DString(255)
},{
	name : en_ligne, 
	isNull : false, 
	t : DString(255)
},{
	name : lang, 
	isNull : false, 
	t : DString(11)
},{
	name : id_ref, 
	isNull : false, 
	t : DInt
}]
} ::> Api.hx 343 recClassMap
INFO - 2013-04-13 11:31:08 --> unique=titre ::> Api.hx 348 recClassMap
INFO - 2013-04-13 11:31:08 --> after ::> Api.hx 358 recClassMap
INFO - 2013-04-13 11:31:08 --> record ::> MicroCreator.hx 62 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviourtitre--pokilolnnn ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviourdate--2013-04-13 ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviourdatelitterale-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviourcontenu-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviourimage-- ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> formElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> FormElementBehaviouren_ligne--false ::> FormElementBehaviour.hx 36 record
INFO - 2013-04-13 11:31:08 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> dataElement ::> MicroCreator.hx 64 record
INFO - 2013-04-13 11:31:08 --> voName=News ::> Pipo.hx 93 nav
INFO - 2013-04-13 11:31:08 --> choix id=null vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:31:08 --> micrabeLast ::> Api.hx 223 getLast
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pokilolnnn
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:08 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:31:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:31:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:31:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:31:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:31:09 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:31:09 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:31:09 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:31:09 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:31:09 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:31:09 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:31:09 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:31:09 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:31:09 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:31:09 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:31:09 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:31:09 --> length=5 ::> Api.hx 161 tags
INFO - 2013-04-13 11:31:14 --> choix id=17 vo=News ::> Pipo.hx 108 choix
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : pokilolnnn
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxDate, 
	type : formElement, 
	champs : 2013-04-13 00:00:00
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	classe : microbe.form.elements.AjaxInput, 
	type : formElement, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.AjaxEditor, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.ImageUploader, 
	champs : 
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> Newsit s a formElement >{
	type : formElement, 
	classe : microbe.form.elements.CheckBox, 
	champs : false
} ::> FormElementBehaviour.hx 23 create
INFO - 2013-04-13 11:31:14 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:31:14 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:31:14 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:31:14 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:31:14 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:31:14 --> before ::> TagManager.hx 133 getTaxoBySpodID
INFO - 2013-04-13 11:31:14 --> microbe.TagManager.getTags{} ::> Api.hx 160 tags
INFO - 2013-04-13 11:31:14 --> length=0 ::> Api.hx 161 tags
INFO - 2013-04-13 11:31:15 --> spod ::> Api.hx 150 tags
INFO - 2013-04-13 11:31:15 --> spodnews ::> Api.hx 155 tags
INFO - 2013-04-13 11:31:15 --> getSpoTablenews ::> TagManager.hx 317 getSpodTable
INFO - 2013-04-13 11:31:15 --> spodablevo.News ::> TagManager.hx 322 getSpodTable
INFO - 2013-04-13 11:31:15 --> managersys.db.Manager ::> TagManager.hx 324 getSpodTable
INFO - 2013-04-13 11:31:15 --> spodTAble=actu ::> TagManager.hx 93 getTaxos
INFO - 2013-04-13 11:31:15 --> resultSet=sys.db._Mysql.MysqlResultSetspodTAble=actu ::> TagManager.hx 101 getTaxos
INFO - 2013-04-13 11:31:15 --> microbe.TagManager.getTags{microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag, microbe.Tag} ::> Api.hx 160 tags
INFO - 2013-04-13 11:31:15 --> length=5 ::> Api.hx 161 tags
