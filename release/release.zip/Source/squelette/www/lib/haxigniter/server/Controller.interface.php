<?php

interface haxigniter_server_Controller {
	//;
	//;
}
