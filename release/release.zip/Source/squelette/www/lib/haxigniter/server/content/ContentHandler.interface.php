<?php

interface haxigniter_server_content_ContentHandler {
	function output($content);
	function input($content);
}
