<?php

interface haxigniter_server_routing_Router {
	function createController($config, $url);
}
