<?php

class haxigniter_server_views_ErazorVars {
	public function __construct() { 
	}
	function __toString() { return 'haxigniter.server.views.ErazorVars'; }
}
