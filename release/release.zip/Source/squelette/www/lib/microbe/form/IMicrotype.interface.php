<?php

interface microbe_form_IMicrotype {
	function toString();
	//;
	//;
	//;
	//;
}
