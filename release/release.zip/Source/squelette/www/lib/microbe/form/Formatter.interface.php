<?php

interface microbe_form_Formatter {
	function format($data);
}
