<?php

interface microbe_vo_Page {
}
