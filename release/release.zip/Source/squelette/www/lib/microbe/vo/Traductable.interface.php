<?php

interface microbe_vo_Traductable {
	function getTrad($lang);
	//;
	//;
}
