<?php

interface microbe_vo_Imbricable {
	//;
}
