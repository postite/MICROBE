<?php

interface microbe_vo_Spodable {
	//;
	function getDefaultField();
	function getFormule();
	//;
}
