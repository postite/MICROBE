<?php

interface microbe_vo_Taggable {
	function getTags();
}
