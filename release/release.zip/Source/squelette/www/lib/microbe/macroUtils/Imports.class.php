<?php

class microbe_macroUtils_Imports {
	public function __construct(){}
	function __toString() { return 'microbe.macroUtils.Imports'; }
}
