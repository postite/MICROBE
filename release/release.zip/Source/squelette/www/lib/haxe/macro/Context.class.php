<?php

class haxe_macro_Context {
	public function __construct(){}
	function __toString() { return 'haxe.macro.Context'; }
}
