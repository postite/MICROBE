<?php

interface haxe_rtti_Infos {
}
