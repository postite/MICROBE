<?php

interface vo_Traductable {
	function getTrad($lang);
	//;
	//;
}
