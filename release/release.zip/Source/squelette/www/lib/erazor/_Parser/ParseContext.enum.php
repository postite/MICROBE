<?php

class erazor__Parser_ParseContext extends Enum {
	public static $code;
	public static $literal;
	public static $__constructors = array(1 => 'code', 0 => 'literal');
	}
erazor__Parser_ParseContext::$code = new erazor__Parser_ParseContext("code", 1);
erazor__Parser_ParseContext::$literal = new erazor__Parser_ParseContext("literal", 0);
